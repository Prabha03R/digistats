import 'package:docmentscan/cubits/signin_cubit.dart';
import 'package:docmentscan/screens/admin_login.dart';
import 'package:docmentscan/screens/common_login.dart';
import 'package:docmentscan/screens/employee_login.dart';
import 'package:docmentscan/screens/profile.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'cubits/add_admin_cubit.dart';
import 'cubits/add_document_cubit/adddocument_cubit.dart';
import 'cubits/add_employee_cubit.dart';
import 'cubits/employeedata_cubit.dart';
import 'cubits/getadmindata_cubit.dart';
import 'cubits/getemployee_cubit.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (context) => AddAdminCubit(),
        ),
        BlocProvider(
          create: (context) => AddEmployeeCubit(),
        ),
        BlocProvider(
          create: (context) => GetemployeeCubit(),
        ),
        BlocProvider(
          create: (context) => SigninCubit(),
        ),
        BlocProvider(
          create: (context) => GetadmindataCubit(),
        ),
        BlocProvider(
          create: (context) => EmployeedataCubit(),
        ),
        BlocProvider(
          create: (context) => AdddocumentCubit(),lazy: false,
        ),
      ],
      child: MaterialApp(
        title: 'Scanning Application',
        theme: ThemeData(
          textTheme: TextTheme(
            bodyLarge: GoogleFonts.poppins(
              textStyle: TextStyle(
                  color: Colors.black,
                  fontSize: 20,
                  fontWeight: FontWeight.w600),
            ),
            bodySmall: GoogleFonts.poppins(
              textStyle: TextStyle(
                  color: Colors.black,
                  fontSize: 12,
                  fontWeight: FontWeight.w400),
            ),
            labelSmall: GoogleFonts.poppins(
              textStyle: TextStyle(
                  color: Colors.black,
                  fontSize: 8,
                  fontWeight: FontWeight.w400),
            ),
            bodyMedium: GoogleFonts.poppins(
              textStyle: TextStyle(
                  color: Colors.black,
                  fontSize: 16,
                  fontWeight: FontWeight.w700),
            ),
            headlineLarge: GoogleFonts.poppins(
              textStyle: TextStyle(
                  color: Colors.black,
                  fontSize: 22,
                  fontWeight: FontWeight.w800),
            ),
            headlineSmall: GoogleFonts.poppins(
              textStyle: TextStyle(
                  color: Colors.black,
                  fontSize: 17,
                  fontWeight: FontWeight.w500),
            ),
            titleSmall: GoogleFonts.poppins(
              textStyle: TextStyle(
                  color: Colors.black,
                  fontSize: 14,
                  fontWeight: FontWeight.w500),
            ),
          ),
          colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
          useMaterial3: true,
        ),
        routes: {
          'commonlogin': (context) => const Commonlogin(),
          'adminlogin': (context) => const Adminlogin(),
          'emplogin': (context) => const Loginpage(),
        },
        home: MyHomePage(
          title: '',
        ),
      ),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  String phno='';
  String email='';
  @override
  void initState() {
    // TODO: implement initState
    getData();
    super.initState();
  }

  void getData()async{
    final SharedPreferences prefs =await SharedPreferences.getInstance();
    phno= prefs.getString('phno')??'';
    email= prefs.getString('email')??'';
}
  @override
  Widget build(BuildContext context) {
        if(phno.isNotEmpty || email.isNotEmpty){
          if(phno.isNotEmpty || phno!=""){
            return Profile(userType:"employee");
          }else if(email.isNotEmpty || email!=""){
            return  Profile(userType:"admin");
          }else{
            return Container(color: Colors.white,);
          }
        }else{
          return Commonlogin();
        }



  }
}
