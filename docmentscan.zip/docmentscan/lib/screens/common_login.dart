import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Commonlogin extends StatefulWidget {
  const Commonlogin({super.key});

  @override
  State<Commonlogin> createState() => _CommonloginState();
}

class _CommonloginState extends State<Commonlogin> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromRGBO(15, 133, 219, 1),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Stack(
              children: [
                Container(
                  height: 426,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(40),
                      bottomRight: Radius.circular(40),
                    ),
                    color: Color.fromRGBO(66, 155, 237, 1),
                  ),
                ),
                Container(
                  height: 414,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(46),
                      bottomRight: Radius.circular(46),
                    ),
                    color: Colors.white,
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const SizedBox(
                        height: 194,
                      ),
                      InkWell(
                        onTap: () {
                          Navigator.of(context)
                              .pushNamed('adminlogin');
                        },
                        child: Container(
                          height: 46,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(12),
                              color: Color.fromRGBO(15, 133, 219, 1)),
                          margin: EdgeInsets.only(right: 22, left: 22),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                'Admin Login',
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyMedium
                                    ?.apply(
                                        color:
                                            Color.fromRGBO(255, 255, 255, 1)),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 40,
                      ),
                      InkWell(
                        onTap: () {
                          Navigator.of(context)
                              .pushNamed('emplogin');
                        },
                        child: Container(
                          height: 46,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(12),
                              color: Color.fromRGBO(15, 133, 219, 1)),
                          margin: EdgeInsets.only(right: 22, left: 22),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                'Employee Login',
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyMedium
                                    ?.apply(
                                        color:
                                            Color.fromRGBO(255, 255, 255, 1)),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(
              height: 130,
            ),
            Column(
              children: [
                Text(
                  'Scanning ',
                  style: Theme.of(context)
                      .textTheme
                      .headlineLarge
                      ?.apply(color: Colors.white),
                ),
                Text(
                  'Application',
                  style: Theme.of(context)
                      .textTheme
                      .headlineLarge
                      ?.apply(color: Colors.white),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
