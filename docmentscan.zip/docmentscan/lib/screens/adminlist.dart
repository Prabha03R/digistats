import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../cubits/getadmindata_cubit.dart';
import '../cubits/getemployee_cubit.dart';
import '../models/admindata.dart';

class Adminlist extends StatefulWidget {
  const Adminlist(
      {super.key,
      required this.pdfDocument,
      required this.nameOfDocSender,
      required this.employeeUserId});

  final String pdfDocument;
  final String nameOfDocSender;
  final String employeeUserId;

  @override
  State<Adminlist> createState() => _AdminlistState();
}

class _AdminlistState extends State<Adminlist> {
  String imagePath = '';

  @override
  void initState() {
    super.initState();
    context.read<GetadmindataCubit>().getadminData();
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<GetadmindataCubit, GetadmindataState>(
      builder: (context, adminstate) {
        if (adminstate is Getadmindataloaded) {
          List<Admindata> admindata = adminstate.admindata;

          return Scaffold(
              appBar: AppBar(
                title: Text(
                  'Admin List',
                  style: Theme.of(context).textTheme.headlineSmall?.apply(
                        color: Color.fromRGBO(255, 255, 255, 1),
                      ),
                ),
                iconTheme: IconThemeData(color: Colors.white),
                backgroundColor: Color.fromRGBO(66, 155, 237, 1),
              ),
              backgroundColor: Color.fromRGBO(226, 238, 250, 1),
              body: ListView.builder(
                  padding: EdgeInsets.only(top: 19),
                  itemCount: admindata.length,
                  itemBuilder: (BuildContext context, int index) {
                    imagePath = adminstate.admindata[index].image ?? "";
                    return Container(
                      margin: EdgeInsets.only(
                        left: 20,
                        right: 20,
                        top: 10,
                      ),
                      padding: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8),
                          color: Colors.white),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              imagePath == ""
                                  ? Image.asset(
                                      'assets/profile.png',
                                      height: 50,
                                      width: 50,
                                    )
                                  : CircleAvatar(
                                      backgroundColor: Colors.transparent,
                                      radius: 30,
                                      onBackgroundImageError:
                                          (exception, stackTrace) =>
                                              Image.asset(
                                        'assets/profile.png',
                                        height: 50,
                                        width: 50,
                                      ),
                                      backgroundImage: NetworkImage(imagePath),
                                    ),
                              const SizedBox(
                                width: 16,
                              ),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    '${admindata[index].firstname} ${admindata[index].lastname}',
                                    style:
                                        Theme.of(context).textTheme.titleSmall,
                                  ),
                                  Text(
                                    '${admindata[index].email}',
                                    style:
                                        Theme.of(context).textTheme.bodySmall,
                                  ),
                                ],
                              ),
                            ],
                          ),
                          InkWell(
                            onTap: () async {
                              print(
                                  "sdkjfcsdjcvsldvsldf ( ${admindata[index].id}");
                              //  var recollection = .doc(receiverId);
                              final SharedPreferences prefs =
                                  await SharedPreferences.getInstance();
                              String? phno = prefs.getString('phno');
                              FirebaseFirestore.instance
                                  .collection('users')
                                  .doc(admindata[index].id)
                                  .set({
                                "sendDocuments": FieldValue.arrayUnion([
                                  {
                                    "pdfDocument": '${widget.pdfDocument}',
                                    "senderName": '${widget.nameOfDocSender}',
                                    "date":
                                        "${DateFormat('dd-mm-yyyy').format(DateTime.now())}"
                                  }
                                ])
                              }, SetOptions(merge: true)).then((value) {
                                FirebaseFirestore.instance
                                    .collection("employee")
                                    .doc(widget.employeeUserId)
                                    .update({
                                  "documents": FieldValue.arrayRemove(
                                      [widget.pdfDocument])
                                });
                                Fluttertoast.showToast(
                                    msg: "PDF Send Successfully",
                                    backgroundColor: Colors.green,
                                    textColor: Colors.white);
                                Navigator.pop(context);
                                context
                                    .read<GetemployeeCubit>()
                                    .getUseData(phno: phno ?? "");
                              });
                            },
                            child: Container(
                                //  margin: EdgeInsets.all(10),
                                padding: EdgeInsets.all(4),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(4),
                                  color: Colors.blue,
                                ),
                                // height: 20,width: 40,

                                child: Text(
                                  'Sent Pdf',
                                  style: Theme.of(context)
                                      .textTheme
                                      .titleSmall
                                      ?.apply(color: Colors.white),
                                )),
                          ),
                        ],
                      ),
                    );
                  }));
        } else {
          return Center(
              child: CircularProgressIndicator(
            strokeWidth: 8,
          ));
        }
      },
    );
  }
}
