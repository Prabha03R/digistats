import 'package:docmentscan/screens/successs_page.dart';
import 'package:email_otp/email_otp.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

class Forgetpassword extends StatefulWidget {
  const Forgetpassword({super.key});

  @override
  State<Forgetpassword> createState() => _ForgetpasswordState();
}

class _ForgetpasswordState extends State<Forgetpassword> {
  final formKey = GlobalKey<FormState>();
  TextEditingController emailController = TextEditingController();
  TextEditingController otp = TextEditingController();
  EmailOTP myauth = EmailOTP();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        margin: EdgeInsets.only(left: 20),
        child: SingleChildScrollView(
          child: Form(
            key: formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(
                  height: 50,
                ),
                InkWell(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Container(
                      height: 26,
                      width: 26,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(4),
                          color: Color.fromRGBO(246, 246, 246, 1)),
                      child: Icon(Icons.arrow_back,
                          size: 18, color: Color.fromRGBO(0, 8, 66, 1))),
                ),
                const SizedBox(
                  height: 22,
                ),
                Text('Forgot Password',
                    style: Theme.of(context)
                        .textTheme
                        .bodyLarge
                        ?.apply(color: Color.fromRGBO(49, 49, 49, 1))),
                const SizedBox(
                  height: 20,
                ),
                Text(
                  'Enter Your email address.We will send on OTP code for verification in the next step',
                  style: Theme.of(context).textTheme.bodySmall?.apply(
                      fontSizeDelta: 2, color: Color.fromRGBO(37, 37, 37, 1)),
                ),
                const SizedBox(
                  height: 14,
                ),
                Container(
                  padding: EdgeInsets.only(right: 20),
                  child: TextFormField(
                    controller: emailController,
                    style: Theme.of(context).textTheme.bodySmall?.apply(
                        color: Color.fromRGBO(102, 100, 100, 1),
                        fontSizeDelta: 2),
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                          borderSide: BorderSide(
                              color: Color.fromRGBO(217, 212, 218, 1))),
                      enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                              color: Color.fromRGBO(217, 212, 218, 1))),
                      focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                              color: Color.fromRGBO(217, 212, 218, 1))),
                      focusedErrorBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                              color: Color.fromRGBO(217, 212, 218, 1))),
                      errorBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.red)),
                      labelStyle: Theme.of(context).textTheme.bodySmall?.apply(
                            color: Color.fromRGBO(102, 100, 100, 1),
                          ),
                      prefixIcon: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const SizedBox(
                            width: 8,
                          ),
                          Icon(Icons.mail_outline,
                              size: 18, color: Color.fromRGBO(0, 8, 66, 1)),
                          Container(
                            width: 1,
                            height: 12,
                            color: Color.fromRGBO(102, 100, 100, 1),
                            margin: EdgeInsets.only(left: 8, right: 8),
                          )
                        ],
                      ),
                      hintText: 'Enter Your Email Id',
                      hintStyle: Theme.of(context).textTheme.bodySmall?.apply(
                          color: Color.fromRGBO(102, 100, 100, 1),
                          fontSizeDelta: 2),
                      labelText: 'Email',
                    ),
                    onSaved: (String? value) {},
                    validator: (value) {
                      if (value!.isEmpty)
                      {
                        return "Please Enter your email";
                      } else if (!RegExp(
                              r'^.+@[a-zA-Z]+\.{1}[a-zA-Z]+(\.{0,1}[a-zA-Z]+)$')
                          .hasMatch(value)) {
                        return "Please Enter a Valid Email ";
                      }
                    },
                  ),
                ),
                const SizedBox(
                  height: 430,
                ),
                InkWell(
                  onTap: () {
    if (formKey.currentState!.validate()) {
      sendCustomPasswordResetCode(emailController.value.text);
      showDialog(
            context: context,
            builder: (BuildContext context) {
              return Dialog(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20.0)),
                child: Sucesspage(),
              );
            });
    }else{
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
              content: Text('Please fill all field')),
      );
    }

                  },
                  child: Container(
                    height: 44,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        color: Color.fromRGBO(15, 133, 219, 1)),
                    margin: EdgeInsets.only(right: 20, left: 20),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'Continue',
                          style: Theme.of(context)
                              .textTheme
                              .headlineSmall
                              ?.apply(color: Color.fromRGBO(255, 255, 255, 1)),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  final FirebaseAuth _auth = FirebaseAuth.instance;

  Future<void> sendCustomPasswordResetCode(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email);
      print('Custom password reset code sent');
    } catch (e) {
      print('Error sending custom password reset code: $e');
      Fluttertoast.showToast(msg: "$e");
    }
  }
}
