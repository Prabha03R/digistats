import 'package:intl/intl.dart';

import 'dart:io' as io;
import 'dart:io';
import 'package:advance_pdf_viewer2/advance_pdf_viewer.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:docmentscan/cubits/getemployee_cubit.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/getemployee.dart';
import 'adminlist.dart';

class MyGridView extends StatelessWidget {
  String? getPhNo() {
    SharedPreferences.getInstance().then((value) {
      return value.getString('phno');
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromRGBO(226, 238, 250, 1),
      body: BlocBuilder<GetemployeeCubit, GetemployeeState>(
        builder: (context, empstate) {
          if (empstate is Getemployeeloaded) {
            print(empstate.runtimeType);
            List<Employeedetails> empdetails =
                empstate.props.first as List<Employeedetails>;
            String phno = empstate.props.last as String;
            // String? phno= pref.getString('phno');

            print(phno);

            Employeedetails curEmp =
                empdetails.firstWhere((element) => element.phno == phno);
            return Padding(
              padding: const EdgeInsets.only(top: 18.0, left: 16, right: 16),
              child: GridView.builder(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2, // Number of columns in the grid
                  crossAxisSpacing: 10.0, // Spacing between columns
                  mainAxisSpacing: 10.0, // Spacing between rows
                ),
                itemCount: curEmp.docs?.length,
                itemBuilder: (BuildContext context, int index) {
                  //  _scannedDocument = _loadPdf(empdetails[0].docs?[index]) as PDFDocument?;
                  return InkWell(
                      onTap: () async {
                        showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            // Return the dialog content inside the Dialog widget
                            return Dialog(
                              insetPadding: EdgeInsets.only(
                                left: 16,
                                right: 16,
                              ),
                              // Optionally, you can set the shape of the dialog
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              // Content of the dialog
                              child: Container(
                                padding: EdgeInsets.all(16.0),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Row(
                                          children: [
                                            Image.asset(
                                              'assets/send.png',
                                            ),
                                            const SizedBox(
                                              width: 10,
                                            ),
                                            Text(
                                              'Sent',
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .titleSmall,
                                            ),
                                          ],
                                        ),
                                        InkWell(
                                            onTap: () {
                                              Navigator.pop(context);
                                              Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                  builder: (context) => Adminlist(
                                                      employeeUserId:
                                                          curEmp.id ?? '',
                                                      pdfDocument:
                                                          curEmp.docs?[index],
                                                      nameOfDocSender:
                                                          "${curEmp.firstname} ${curEmp.lastname}"),
                                                ),
                                              );
                                            },
                                            child: Icon(
                                              Icons.arrow_forward_ios,
                                              size: 20,
                                            ))
                                      ],
                                    ),
                                    Container(
                                      height: 1,
                                      margin:
                                          EdgeInsets.only(top: 14, bottom: 14),
                                    ),
                                    Row(
                                      children: [
                                        Icon(Icons.delete),
                                        const SizedBox(
                                          width: 10,
                                        ),
                                        InkWell(
                                          onTap: () async {
                                            List DocList = curEmp.docs ?? [];
                                            DocList.remove(curEmp.docs?[index]);
                                            await FirebaseFirestore.instance
                                                .collection("employee")
                                                .doc(curEmp.id ?? '')
                                                .set({
                                              "documents": DocList
                                            }, SetOptions(merge: true)).then(
                                                    (value) {
                                              Navigator.pop(context);
                                              context
                                                  .read<GetemployeeCubit>()
                                                  .getUseData(phno: phno ?? "");
                                            });
                                            Fluttertoast.showToast(
                                                msg: "PDF delete Successfully",
                                                backgroundColor: Colors.green,
                                                textColor: Colors.white);
                                          },
                                          child: Text(
                                            'Delete',
                                            style: Theme.of(context)
                                                .textTheme
                                                .titleSmall,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        );
                        // Navigator.push(context, MaterialPageRoute(builder: (context)=>ViewPdfDOCPage(
                        //   pdfUrl: curEmp.docs?[index],
                        // )));

                        // print('Document uploaded to Firebase: $downloadURL');
                        // final SharedPreferences prefs =await SharedPreferences.getInstance();
                        // String? phno= prefs.getString('phno');
                        // Employeedetails curEmp= empdetails.firstWhere((element) => element.docs[index].f==phno);
                        // List<Employeedetails> submitteddoclist=[];
                        // submitteddoclist.add(curEmp.docs?[index]);
                        //
                        //     FirebaseFirestore.instance.collection('employee').doc(curEmp.id).set(
                        //         {
                        //           "submittddocuments":submitteddoclist
                        //         },
                        //         SetOptions(merge: true)
                        //     );
                        // Handle the downloadURL as needed
                      },
                      child: PdfViewerPage(
                          pdfUrl: curEmp.docs?[index],
                          text1: 'User : ${curEmp.senderName}',
                          text2: 'Date : ${curEmp.date}')
                      // Container(
                      //   color: Colors.cyan,
                      //   child: Column(
                      //     mainAxisSize: MainAxisSize.min,
                      //     children: [
                      //       Container(
                      //         child: _isLoading
                      //             ? Center(child: CircularProgressIndicator(strokeWidth: 0.5,))
                      //             : Container(
                      //             decoration: BoxDecoration(borderRadius: BorderRadius.circular(5),color: Colors.white,
                      //
                      //             ),
                      //
                      //             height: 200,
                      //             width: 160,
                      //             // height: MediaQuery.of(context).size.height,
                      //             child: (_scannedDocument==null)?Text("No data"):PDFViewer(
                      //               showNavigation: false,
                      //               showIndicator: false,
                      //               showPicker: false,
                      //               zoomSteps: 2,
                      //               document: _scannedDocument!,
                      //               // enableSwipeNavigation: false,
                      //             )),
                      //       ),
                      //       Text('user : ${empdetails[0].firstname} ${empdetails[0].lastname}'),
                      //       Text('Date : ${DateFormat('dd-mm-yyyy').format(DateTime.now())}'),
                      //
                      //     ],
                      //   ),
                      // ),
                      );
                },
              ),
            );
          } else {
            return Center(
                child: CircularProgressIndicator(
              strokeWidth: 0.5,
            ));
          }
        },
      ),
    );
  }
}

class PdfViewerPage extends StatefulWidget {
  final String pdfUrl;
  final String text1;
  final String text2;

  PdfViewerPage(
      {required this.pdfUrl, required this.text1, required this.text2});

  @override
  _PdfViewerPageState createState() => _PdfViewerPageState();
}

class _PdfViewerPageState extends State<PdfViewerPage> {
  int _totalPages = 0;
  int _currentPage = 0;
  bool _isLoading = true;
  PDFDocument? _scannedDocument;

  @override

  void initState() {
    // TODO: implement initState
    super.initState();
    _loadPdf();
  }

  void _loadPdf() async {
    _scannedDocument = await PDFDocument.fromURL(widget.pdfUrl);
    setState(() {
      _isLoading = false;
    });
    // Use 'doc' to interact with the loaded PDF, if needed.
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: Container(
            child: _isLoading
                ? Center(
                    child:
                //Icon(Icons.picture_as_pdf_sharp)
                    CircularProgressIndicator(
                    strokeWidth: 0.5,
                  )
            )
                : Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5),
                      color: Colors.white,
                    ),
                    height: 200,
                    width: 160,
                    // height: MediaQuery.of(context).size.height,
                    child: (_scannedDocument == null)
                        ? Text("No data")
                        : PDFViewer(
                      progressIndicator:Center(
                          child:Icon(Icons.picture_as_pdf_sharp)

                      ) ,

                      lazyLoad: false,
                            showNavigation: false,
                            showIndicator: false,
                            showPicker: false,
                            zoomSteps: 2,
                            document: _scannedDocument!,
                            // enableSwipeNavigation: false,
                          )),
          ),
        ),
        Container(
          width: 300,
          padding: EdgeInsets.only(left: 10),
          color: Colors.white,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            // mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Text(widget.text1, style: Theme.of(context).textTheme.titleSmall),
              Text(
                widget.text2,
                style: Theme.of(context).textTheme.titleSmall,
              ),
            ],
          ),
        ),
      ],
    );
  }
}
//
// class ViewPdfDOCPage extends StatefulWidget {
//   const ViewPdfDOCPage({super.key, required this.pdfUrl});
//
//   final String pdfUrl;
//
//   @override
//   State<ViewPdfDOCPage> createState() => _ViewPdfDOCPageState();
// }
//
// class _ViewPdfDOCPageState extends State<ViewPdfDOCPage> {
//   int _totalPages = 0;
//   int _currentPage = 0;
//   bool _isLoading = true;
//   PDFDocument? _scannedDocument;
//
//   @override
//   void initState() {
//     // TODO: implement initState
//     super.initState();
//     _loadPdf();
//   }
//
//   void _loadPdf() async {
//     _scannedDocument = await PDFDocument.fromURL(widget.pdfUrl);
//     setState(() {
//       _isLoading = false;
//     });
//     // Use 'doc' to interact with the loaded PDF, if needed.
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Container(
//         height: MediaQuery.of(context).size.height,
//         child: _isLoading
//             ? Center(
//                 child: CircularProgressIndicator(
//                 strokeWidth: 0.5,
//               ))
//             : (_scannedDocument == null)
//                 ? Text("No data")
//                 : PDFViewer(
//                     document: _scannedDocument!,
//                   ),
//       ),
//     );
//   }
// }
