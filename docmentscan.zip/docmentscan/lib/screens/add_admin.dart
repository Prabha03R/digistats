import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

import 'package:firebase_storage/firebase_storage.dart'; // <-- Add this import

import '../cubits/add_admin_cubit.dart';
import 'package:intl/intl.dart';

class Addadmin extends StatefulWidget {
  const Addadmin({super.key});

  @override
  State<Addadmin> createState() => _AddadminState();
}

class _AddadminState extends State<Addadmin> {
  File? _pickedImage;

  Future<void> _handleImagePick(BuildContext context) async {
    final XFile? image = await pickImage();
    if (image != null) {
      setState(() {
        _pickedImage = File(image.path);
      });
      // String? downloadURL = await uploadImageToFirebase(File(image.path));
      // if (downloadURL != null) {
      //   // Handle the download URL as needed (e.g., save it to Firestore, display it, etc.).
      //   print('Download URL: $downloadURL');
      // } else {
      //   // Handle the error.
      //   print('Image upload failed.');
      // }
    }
  }

  Future<XFile?> pickImage() async {
    final ImagePicker _picker = ImagePicker();
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    return image;
  }

  Future<String?> uploadImageToFirebase(File imageFile) async {
    // try {
    final String fileName = DateTime.now().millisecondsSinceEpoch.toString();
    final Reference storageReference = FirebaseStorage.instance.ref().child(
        'AdminProfiles/$fileName'); // Create the path with the specified folder name

    final UploadTask uploadTask = storageReference.putFile(imageFile);
    final TaskSnapshot storageSnapshot =
        await uploadTask.whenComplete(() => null);

    final String downloadURL = await storageSnapshot.ref.getDownloadURL();

    return downloadURL;
    // } catch (e) {
    //   print('Error uploading image to Firebase: $e');
    //   return null;
    // }
  }

  var items = [
    'Male',
    'Female',
  ];
  String dropdownvalue = 'Male';

  final _formKey = GlobalKey<FormState>();
  TextEditingController firstnameController = TextEditingController();
  TextEditingController lastnameController = TextEditingController();
  TextEditingController genderController = TextEditingController();
  TextEditingController dobController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController addressController = TextEditingController();

  @override
  void initState() {
    dobController.text = ""; //set the initial value of text field
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AddAdminCubit, AddAdminState>(
      builder: (context, addState) {
        if (addState is AddAdminloaded) {
          Future.delayed(Duration.zero, () {
            Navigator.pop(context);
          });
          context.read<AddAdminCubit>().reset();
        }
        return SingleChildScrollView(
          child: Container(
            padding: EdgeInsets.only(left: 16, right: 16),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Color.fromRGBO(226, 238, 250, 1)),
            //  height: 450,
            // width: 328,
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(
                    height: 12,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('Add Admin',
                          style: Theme.of(context).textTheme.titleSmall?.apply(
                              color: Color.fromRGBO(49, 49, 49, 1),
                              fontSizeDelta: 2)),
                    ],
                  ),
                  const SizedBox(
                    height: 26,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      InkWell(
                        onTap: () {
                          _handleImagePick(context);
                        },
                        child: CircleAvatar(
                            radius: 42,
                            backgroundColor: Colors.transparent,
                            child: Stack(
                              children: [
                                _pickedImage == null
                                    ? Image.asset('assets/user.png')
                                    : Container(
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(20),
                                          image: DecorationImage(
                                            image: FileImage(_pickedImage!),
                                            fit: BoxFit.cover,
                                          ),
                                        ),
                                      ),
                                Positioned(
                                    bottom: 0,
                                    right: 0,
                                    child: Image.asset('assets/edit.png')),
                              ],
                            )),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 24,
                  ),
                  Container(
                    height: 44,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5),
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                            spreadRadius: 0,
                            blurRadius: 3,
                            color: Color.fromRGBO(0, 0, 0, 0.1))
                      ],
                    ),
                    child: TextFormField(
                      controller: firstnameController,
                      style: Theme.of(context).textTheme.bodySmall?.apply(
                          color: Color.fromRGBO(102, 100, 100, 1),
                          fontSizeDelta: 2),
                      decoration: InputDecoration(
                          border: OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: Colors.transparent)),
                          enabledBorder: OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: Colors.transparent)),
                          focusedBorder: OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: Colors.transparent)),
                          hintText: 'First Name',
                          hintStyle: Theme.of(context)
                              .textTheme
                              .bodySmall
                              ?.apply(
                                  color: Color.fromRGBO(102, 100, 100, 1),
                                  fontSizeDelta: 2),
                          contentPadding: EdgeInsets.only(top: 6, left: 18)),
                      onSaved: (String? value) {},
                    ),
                  ),
                  const SizedBox(
                    height: 14,
                  ),
                  Container(
                    height: 44,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5),
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                            spreadRadius: 0,
                            blurRadius: 3,
                            color: Color.fromRGBO(0, 0, 0, 0.1))
                      ],
                    ),
                    child: TextFormField(
                      controller: lastnameController,
                      style: Theme.of(context).textTheme.bodySmall?.apply(
                          color: Color.fromRGBO(102, 100, 100, 1),
                          fontSizeDelta: 2),
                      decoration: InputDecoration(
                          border: OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: Colors.transparent)),
                          enabledBorder: OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: Colors.transparent)),
                          focusedBorder: OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: Colors.transparent)),
                          hintText: 'Last Name',
                          hintStyle: Theme.of(context)
                              .textTheme
                              .bodySmall
                              ?.apply(
                                  color: Color.fromRGBO(102, 100, 100, 1),
                                  fontSizeDelta: 2),
                          contentPadding: EdgeInsets.only(top: 6, left: 18)),
                      onSaved: (String? value) {},
                    ),
                  ),
                  const SizedBox(
                    height: 14,
                  ),
                  Container(
                    height: 44,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5),
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                            spreadRadius: 0,
                            blurRadius: 3,
                            color: Color.fromRGBO(0, 0, 0, 0.1))
                      ],
                    ),
                    child: Row(
                      children: [
                        DropdownButton(
                          underline: Container(
                            color: Colors.transparent,
                          ),
                          padding: EdgeInsets.only(left: 20),
                          value: dropdownvalue,
                          icon: Padding(
                            padding: const EdgeInsets.only(left: 186),
                            child: const Icon(Icons.keyboard_arrow_down),
                          ),
                          items: items.map((String items) {
                            return DropdownMenuItem(
                              value: items,
                              child: Text(
                                items,
                                style: Theme.of(context)
                                    .textTheme
                                    .bodySmall
                                    ?.apply(
                                        color: Color.fromRGBO(102, 100, 100, 1),
                                        fontSizeDelta: 2),
                              ),
                            );
                          }).toList(),
                          onChanged: (String? newValue) {
                            setState(() {
                              dropdownvalue = newValue!;
                            });
                          },
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(
                    height: 14,
                  ),
                  Container(
                    height: 44,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5),
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                            spreadRadius: 0,
                            blurRadius: 3,
                            color: Color.fromRGBO(0, 0, 0, 0.1))
                      ],
                    ),
                    child: TextFormField(
                      controller: dobController,
                      style: Theme.of(context).textTheme.bodySmall?.apply(
                          color: Color.fromRGBO(102, 100, 100, 1),
                          fontSizeDelta: 2),
                      decoration: InputDecoration(
                        border: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.transparent)),
                        enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.transparent)),
                        focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.transparent)),
                        hintText: 'Date of Birth',
                        hintStyle: Theme.of(context).textTheme.bodySmall?.apply(
                            color: Color.fromRGBO(102, 100, 100, 1),
                            fontSizeDelta: 2),
                        contentPadding: EdgeInsets.only(top: 6, left: 18),
                        suffixIcon: InkWell(
                            onTap: () async {
                              DateTime? pickedDate = await showDatePicker(
                                  context: context,
                                  initialDate: DateTime.now(),
                                  firstDate: DateTime(1900),
                                  //DateTime.now() - not to allow to choose before today.
                                  lastDate: DateTime(2101));

                              if (pickedDate != null) {
                                print(
                                    pickedDate); //pickedDate output format => 2021-03-10 00:00:00.000
                                String formattedDate =
                                    DateFormat('yyyy-MM-dd').format(pickedDate);
                                print(formattedDate);
                                setState(() {
                                  dobController.text = formattedDate; //set output date to TextField value.
                                });
                              } else {
                                print("Date is not selected");
                              }
                            },
                            child: Icon(
                              Icons.calendar_month,
                              size: 20,
                              color: Color.fromRGBO(65, 165, 238, 1),
                            )),
                      ),
                      onSaved: (String? value) {},
                    ),
                  ),
                  const SizedBox(
                    height: 14,
                  ),
                  Container(
                    height: 44,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5),
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                            spreadRadius: 0,
                            blurRadius: 3,
                            color: Color.fromRGBO(0, 0, 0, 0.1))
                      ],
                    ),
                    child: TextFormField(
                      controller: emailController,
                      style: Theme.of(context).textTheme.bodySmall?.apply(
                          color: Color.fromRGBO(102, 100, 100, 1),
                          fontSizeDelta: 2),
                      decoration: InputDecoration(
                        border: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.transparent)),
                        enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.transparent)),
                        focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.transparent)),
                        hintText: 'Email',
                        hintStyle: Theme.of(context).textTheme.bodySmall?.apply(
                            color: Color.fromRGBO(102, 100, 100, 1),
                            fontSizeDelta: 2),
                        contentPadding: EdgeInsets.only(top: 6, left: 18),
                      ),
                      onSaved: (String? value) {},
                    ),
                  ),
                  const SizedBox(
                    height: 14,
                  ),
                  Container(
                    height: 44,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5),
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                            spreadRadius: 0,
                            blurRadius: 3,
                            color: Color.fromRGBO(0, 0, 0, 0.1))
                      ],
                    ),
                    child: TextFormField(
                      controller: passwordController,
                      style: Theme.of(context).textTheme.bodySmall?.apply(
                          color: Color.fromRGBO(102, 100, 100, 1),
                          fontSizeDelta: 2),
                      decoration: InputDecoration(
                        border: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.transparent)),
                        enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.transparent)),
                        focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.transparent)),
                        hintText: 'Password',
                        hintStyle: Theme.of(context).textTheme.bodySmall?.apply(
                            color: Color.fromRGBO(102, 100, 100, 1),
                            fontSizeDelta: 2),
                        contentPadding: EdgeInsets.only(top: 6, left: 18),
                      ),
                      onSaved: (String? value) {},
                    ),
                  ),
                  const SizedBox(
                    height: 14,
                  ),
                  Container(
                    height: 44,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5),
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                            spreadRadius: 0,
                            blurRadius: 3,
                            color: Color.fromRGBO(0, 0, 0, 0.1))
                      ],
                    ),
                    child: TextFormField(
                      controller: addressController,
                      style: Theme.of(context).textTheme.bodySmall?.apply(
                          color: Color.fromRGBO(102, 100, 100, 1),
                          fontSizeDelta: 2),
                      decoration: InputDecoration(
                        border: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.transparent)),
                        enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.transparent)),
                        focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.transparent)),
                        hintText: 'Address',
                        hintStyle: Theme.of(context).textTheme.bodySmall?.apply(
                            color: Color.fromRGBO(102, 100, 100, 1),
                            fontSizeDelta: 2),
                        contentPadding: EdgeInsets.only(top: 6, left: 18),
                      ),
                      onSaved: (String? value) {},
                    ),
                  ),
                  const SizedBox(
                    height: 56,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      InkWell(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Container(
                          padding: EdgeInsets.only(right: 32, left: 32),
                          height: 38,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8),
                            color: Color.fromRGBO(243, 250, 255, 1),
                          ),
                          //  margin: EdgeInsets.only(right: 20,left: 20),

                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                'Cancel',
                                style: Theme.of(context)
                                    .textTheme
                                    .titleSmall
                                    ?.apply(
                                        color: Color.fromRGBO(15, 133, 219, 1),
                                        fontSizeDelta: 2),
                              ),
                            ],
                          ),
                        ),
                      ),
                      InkWell(
                        onTap: () async {
                          if (_formKey.currentState!.validate()) {
                            if (_pickedImage?.path != null) {
                              String? downloadURL = await uploadImageToFirebase(
                                  File(_pickedImage!.path));
                              print("skdjvsdj USer Gettedd");
                              context.read<AddAdminCubit>().Addadmin(
                                    firstname: firstnameController.value.text,
                                    lastname: lastnameController.value.text,
                                    gender: dropdownvalue,
                                    dob: dobController.value.text,
                                    email: emailController.value.text,
                                    password: passwordController.value.text,
                                    address: addressController.value.text,
                                    image: downloadURL ?? "null",
                                  );
                              // Navigator.pop(context);
                            } else {
                              Fluttertoast.showToast(
                                  msg: "Kindly Choose Photo Proof");
                            }
                            // Navigate the user to the Home page
                          } else {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                  content: Text('Please fill all field')),
                            );
                          }
                        },
                        child: Container(
                          padding: EdgeInsets.only(right: 32, left: 32),
                          height: 38,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8),
                              color: Color.fromRGBO(15, 133, 219, 1)),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                'Add',
                                style: Theme.of(context)
                                    .textTheme
                                    .titleSmall
                                    ?.apply(
                                        color: Color.fromRGBO(255, 255, 255, 1),
                                        fontSizeDelta: 2),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 40,
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
