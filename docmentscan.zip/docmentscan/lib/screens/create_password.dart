import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:docmentscan/screens/successs_page.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';


class Cretepassword extends StatefulWidget {
  const Cretepassword({super.key});

  @override
  State<Cretepassword> createState() => _CretepasswordState();
}

class _CretepasswordState extends State<Cretepassword> {
  TextEditingController otp = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      body: Container(
        margin: EdgeInsets.only(left: 20),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 50,),
              InkWell(
                onTap: (){
                  Navigator.pop(context);
                },
                child: Container(
                    height: 26
                    ,width: 26,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(4),
                        color:Color.fromRGBO(246, 246, 246, 1)
                    ),
                    child: Icon(Icons.arrow_back,size: 18,color:Color.fromRGBO(0, 8, 66, 1))),
              ),
              const SizedBox(height: 22,),
              Text('Create new password',style: Theme.of(context).textTheme.bodyLarge?.apply(
                  color:Color.fromRGBO(49, 49, 49, 1)
              )),
              const SizedBox(height: 20,),
              Text('Enter Your new password.If you forget it then you have to do forgot password',style: Theme.of(context).textTheme.bodySmall
                  ?.apply(fontSizeDelta: 2,color:Color.fromRGBO(37, 37, 37, 1)),),
              const SizedBox(height: 26,),
              Container(
                padding: EdgeInsets.only(right: 20),
                // decoration: BoxDecoration(border: Border.all()),
                child: TextFormField(
                  // key: formKey,



                    style: Theme.of(context).textTheme.bodySmall?.apply(color:Color.fromRGBO(102, 100, 100, 1),fontSizeDelta: 2),

                    decoration:  InputDecoration(
                      border: OutlineInputBorder(
                          borderSide: BorderSide(color: Color.fromRGBO(217, 212, 218, 1))

                      ),
                      enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Color.fromRGBO(217, 212, 218, 1))

                      ),
                      focusedBorder:OutlineInputBorder(
                          borderSide: BorderSide(color: Color.fromRGBO(217, 212, 218, 1))

                      ),
                      focusedErrorBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Color.fromRGBO(217, 212, 218, 1))

                      ),
                      errorBorder:OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.red)

                      ),

                      labelStyle:  Theme.of(context).textTheme.bodySmall?.apply(color:Color.fromRGBO(102, 100, 100, 1),),

                      hintText: 'Enter Your Password',
                      hintStyle: Theme.of(context).textTheme.bodySmall?.apply(color:Color.fromRGBO(102, 100, 100, 1),fontSizeDelta: 2),
                      labelText: 'Password',



                    ),


                    onSaved: (String? value) {

                    },
                    validator: (value){
                      if(value!.isEmpty){
                        return "Please Enter a Password";
                      }else if(!RegExp(r"(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*\W)").hasMatch(value)){
                        return "Please Enter a Valid Password";
                      }}





                ),
              ),
              const SizedBox(height: 42,),
              Container(
                padding: EdgeInsets.only(right: 20),
                // decoration: BoxDecoration(border: Border.all()),
                child: TextFormField(
                  controller: otp,
                  // key: formKey,



                    style: Theme.of(context).textTheme.bodySmall?.apply(color:Color.fromRGBO(102, 100, 100, 1),fontSizeDelta: 2),

                    decoration:  InputDecoration(
                      border: OutlineInputBorder(
                          borderSide: BorderSide(color: Color.fromRGBO(217, 212, 218, 1))

                      ),
                      enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Color.fromRGBO(217, 212, 218, 1))

                      ),
                      focusedBorder:OutlineInputBorder(
                          borderSide: BorderSide(color: Color.fromRGBO(217, 212, 218, 1))

                      ),
                      focusedErrorBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Color.fromRGBO(217, 212, 218, 1))

                      ),
                      errorBorder:OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.red)

                      ),

                      labelStyle:  Theme.of(context).textTheme.bodySmall?.apply(color:Color.fromRGBO(102, 100, 100, 1),),

                      hintText: 'Enter Your Confirm Password',
                      hintStyle: Theme.of(context).textTheme.bodySmall?.apply(color:Color.fromRGBO(102, 100, 100, 1),fontSizeDelta: 2),
                      labelText: 'Confirm Password',



                    ),


                    onSaved: (String? value) {

                    },
                    validator: (value){
                      if(value!.isEmpty){
                        return "Please Enter a Password";
                      }else if(!RegExp(r"(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*\W)").hasMatch(value)){
                        return "Please Enter a Valid Password";
                      }}


                ),
              ),
              const SizedBox(height: 326,),
              InkWell(
                onTap:(){

                  print('___${otp.value.text}');
                  showDialog(

                      context: context,
                      builder: (BuildContext context) {
                        return Dialog(

                          shape: RoundedRectangleBorder(

                              borderRadius:
                              BorderRadius.circular(20.0)),
                          child:Sucesspage() ,
                        );
                      }
                  );


                },
                child: Container(
                  height: 44,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      color: Color.fromRGBO(15, 133, 219, 1)


                  ),
                  margin: EdgeInsets.only(right: 20,left: 20),


                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('Continue',style: Theme.of(context).textTheme.headlineSmall?.apply(
                          color:Color.fromRGBO(255, 255, 255, 1)
                      ),),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),

      ),
    );
  }

}
