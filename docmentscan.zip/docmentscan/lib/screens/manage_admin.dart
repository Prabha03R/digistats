import 'package:docmentscan/cubits/getadmindata_cubit.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../models/admindata.dart';
import 'add_admin.dart';

class Manageadmin extends StatefulWidget {
  const Manageadmin({super.key});

  @override
  State<Manageadmin> createState() => _ManageadminState();
}

class _ManageadminState extends State<Manageadmin> {
  String imagePath = '';

  @override
  void initState() {
    super.initState();
    context.read<GetadmindataCubit>().getadminData();
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<GetadmindataCubit, GetadmindataState>(
      builder: (context, adminstate) {
        if (adminstate is Getadmindataloaded) {
          List<Admindata> admindata = adminstate.admindata;

          return Scaffold(
              backgroundColor: Color.fromRGBO(226, 238, 250, 1),
              body: Stack(
                children: [
                  ListView.builder(
                      padding: EdgeInsets.only(top: 19),
                      itemCount: admindata.length,
                      itemBuilder: (BuildContext context, int index) {
                        imagePath = adminstate.admindata[index].image ?? "";
                        return InkWell(
                          onTap: () async {
                            showDialog(
                              context: context,
                              builder: (BuildContext context) {
                                // Return the dialog content inside the Dialog widget
                                return Dialog(
                                  insetPadding: EdgeInsets.only(
                                    left: 16,
                                    right: 16,
                                  ),
                                  // Optionally, you can set the shape of the dialog
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                  ),
                                  // Content of the dialog
                                  child: Container(
                                    padding: EdgeInsets.all(16.0),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        InkWell(
                                          onTap: (){
                                            // Navigator.push(
                                            //
                                            //   context,
                                            //   MaterialPageRoute(builder: (context) =>  Addadmin()),
                                            // );
                                          },
                                          child: Row(
                                            children: [
                                              Icon(Icons.edit),
                                              const SizedBox(
                                                width: 10,
                                              ),
                                              Text(
                                                'Edit',
                                                style: Theme.of(context)
                                                    .textTheme
                                                    .titleSmall,
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          height: 1,
                                          margin:
                                          EdgeInsets.only(top: 14, bottom: 14),
                                        ),
                                        Row(
                                          children: [
                                            Icon(Icons.delete),
                                            const SizedBox(
                                              width: 10,
                                            ),
                                            InkWell(
                                              // onTap: () async {
                                              //   List DocList = curEmp.docs ?? [];
                                              //   DocList.remove(curEmp.docs?[index]);
                                              //   await FirebaseFirestore.instance
                                              //       .collection("employee")
                                              //       .doc(curEmp.id ?? '')
                                              //       .set({
                                              //     "documents": DocList
                                              //   }, SetOptions(merge: true)).then(
                                              //           (value) {
                                              //         Navigator.pop(context);
                                              //         context
                                              //             .read<GetemployeeCubit>()
                                              //             .getUseData(phno: phno ?? "");
                                              //       });
                                              //   Fluttertoast.showToast(
                                              //       msg: "PDF delete Successfully",
                                              //       backgroundColor: Colors.green,
                                              //       textColor: Colors.white);
                                              // },
                                              child: Text(
                                                'Delete',
                                                style: Theme.of(context)
                                                    .textTheme
                                                    .titleSmall,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            );

                          },
                          child: Container(
                            margin: EdgeInsets.only(
                              left: 20,
                              right: 20,
                              top: 10,
                            ),
                            padding: EdgeInsets.all(10),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8),
                                color: Colors.white),
                            child: Row(
                              children: [
                                imagePath == ""
                                    ? Image.asset(
                                        'assets/profile.png',
                                        height: 50,
                                        width: 50,
                                      )
                                    : CircleAvatar(
                                        backgroundColor: Colors.transparent,
                                        radius: 30,
                                        onBackgroundImageError:
                                            (exception, stackTrace) =>
                                                Image.asset(
                                          'assets/profile.png',
                                          height: 50,
                                          width: 50,
                                        ),
                                        backgroundImage: NetworkImage(imagePath),
                                      ),
                                const SizedBox(
                                  width: 16,
                                ),
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      '${admindata[index].firstname} ${admindata[index].lastname}',
                                      style:
                                          Theme.of(context).textTheme.titleSmall,
                                    ),
                                    Text(
                                      '${admindata[index].email}',
                                      style:
                                          Theme.of(context).textTheme.bodySmall,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        );
                      }),
                  Positioned(
                    bottom: 0,
                    right: 0,
                    child: InkWell(
                      onTap: () {
                        showDialog(
                            context: context,
                            builder: (BuildContext context) {
                              return Dialog(
                                insetPadding: EdgeInsets.all(16),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10.0)),
                                child: SingleChildScrollView(child: Addadmin()),
                              );
                            });
                      },
                      child: Container(
                        margin: EdgeInsets.only(right: 16, bottom: 16),
                        height: 56,
                        width: 56,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(28),
                            color: Color.fromRGBO(237, 113, 40, 1),
                            boxShadow: [
                              BoxShadow(
                                  spreadRadius: 0,
                                  blurRadius: 4,
                                  color: Color.fromRGBO(0, 0, 0, 0.25))
                            ]),
                        child: Icon(
                          Icons.add,
                          color: Colors.white,
                          size: 26,
                        ),
                      ),
                    ),
                  )
                ],
              ));
        } else {
          return CircularProgressIndicator();
        }
      },
    );
  }
}
