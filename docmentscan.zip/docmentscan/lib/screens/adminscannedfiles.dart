import 'package:firebase_storage/firebase_storage.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'dart:io' show Directory, File, Platform;
import 'package:advance_pdf_viewer2/advance_pdf_viewer.dart';
import 'package:docmentscan/cubits/getadmindata_cubit.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_cached_pdfview/flutter_cached_pdfview.dart';
import 'package:lecle_downloads_path_provider/lecle_downloads_path_provider.dart';
import 'package:open_file/open_file.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/admindata.dart';

class Adminscanfiles extends StatefulWidget {
  const Adminscanfiles({super.key});

  @override
  State<Adminscanfiles> createState() => _AdminscanfilesState();
}

class _AdminscanfilesState extends State<Adminscanfiles> {
  final userdata = FirebaseAuth.instance.currentUser;
  PDFDocument? _scannedDocument;

  @override
  void initState() {
    super.initState();
    context.read<GetadmindataCubit>().getadminData();
    // }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromRGBO(226, 238, 250, 1),
      body: BlocBuilder<GetadmindataCubit, GetadmindataState>(
        builder: (context, adminstate) {
          if (adminstate is Getadmindataloaded) {
            List<Admindata> admindata = adminstate.admindata;

            Admindata curadmin = admindata.firstWhere((element) => element.email == userdata?.email);

            return Padding(
              padding: const EdgeInsets.only(top: 18.0, left: 16, right: 16),
              child: GridView.builder(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2, // Number of columns in the grid
                    crossAxisSpacing: 10.0, // Spacing between columns
                    mainAxisSpacing: 10.0,
                    childAspectRatio: 0.8
                    // Spacing between rows
                    ),
                itemCount: curadmin.sendDocuments?.length,
                itemBuilder: (BuildContext context, int index) {
                  return InkWell(
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => ViewPdfDOCPage(
                                      pdfUrl: curadmin.sendDocuments?[index]
                                              .pdfDocument ??
                                          '', userName: '${curadmin.sendDocuments?[index].senderName}', date: '${curadmin.sendDocuments?[index].date}',
                                    )));
                      },
                      child: PdfViewerPage(
                          pdfUrl:
                              curadmin.sendDocuments?[index].pdfDocument ?? '',
                          text1:
                              'User : ${curadmin.sendDocuments?[index].senderName}',
                          text2:
                              'Date : ${curadmin.sendDocuments?[index].date}'));
                },
              ),
            );
          } else {
            return Center(
              child: CircularProgressIndicator(
                strokeWidth: 0.5,
              ),
            );
          }
        },
      ),
    );
  }
}

class PdfViewerPage extends StatefulWidget {
  final String pdfUrl;
  final String text1;
  final String text2;

  PdfViewerPage(
      {required this.pdfUrl, required this.text1, required this.text2});

  @override
  _PdfViewerPageState createState() => _PdfViewerPageState();
}

class _PdfViewerPageState extends State<PdfViewerPage> {
  int _totalPages = 0;
  int _currentPage = 0;
  bool _isLoading = true;
  PDFDocument? _scannedDocument;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _loadPdf();
  }

  void _loadPdf() async {
    _scannedDocument = await PDFDocument.fromURL(widget.pdfUrl);
    setState(() {
      _isLoading = false;
    });
    // Use 'doc' to interact with the loaded PDF, if needed.
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: Container(
            // color: Colors.cyan,
            child: _isLoading
                ? Center(
                    child: Icon(Icons.picture_as_pdf_sharp))
                : Container(
                    child: (_scannedDocument == null)
                        ? Text("No data")
                        : PDFViewerCachedFromUrl(

                      url:widget.pdfUrl ,
                    ),

              // PDFViewer(
                    //   progressIndicator:Center(
                    //       child:Icon(Icons.picture_as_pdf_sharp)
                    //
                    //   ),
                    //         showNavigation: false,
                    //         showIndicator: false,
                    //         showPicker: false,
                    //         zoomSteps: 2,
                    //         document: _scannedDocument!,
                    //         // enableSwipeNavigation: false,
                    //       )
            ),
          ),
        ),
        Container(
          width: 300,
          padding: EdgeInsets.only(left: 10),
          color: Colors.white,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            // mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Text(widget.text1, style: Theme.of(context).textTheme.titleSmall),
              Text(
                widget.text2,
                style: Theme.of(context).textTheme.titleSmall,
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class ViewPdfDOCPage extends StatefulWidget {
  const ViewPdfDOCPage({super.key, required this.pdfUrl,required this.userName, required this.date});

  final String pdfUrl;
  final String userName;
  final String date;

  @override
  State<ViewPdfDOCPage> createState() => _ViewPdfDOCPageState();
}

class _ViewPdfDOCPageState extends State<ViewPdfDOCPage> {
  // Future<void> _downloadAndOpenPdf() async {
  //   final taskId = await OpenFile.open(widget.pdfUrl, type: "application/pdf");
  //   // Optionally, you can use the taskId to monitor the download progress or handle any error during the download.
  // }
  bool _isLoading = true;
  PDFDocument? _scannedDocument;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _loadPdf();
  }

  void _loadPdf() async {
    _scannedDocument = await PDFDocument.fromURL(widget.pdfUrl);
    setState(() {
      _isLoading = false;
    });
    // Use 'doc' to interact with the loaded PDF, if needed.
  }
  void downloadPDF ()async{
   try {
      if(Platform.isAndroid){

          final ref = FirebaseStorage.instance.refFromURL("${widget.pdfUrl}");
          Directory dir = Directory('/storage/emulated/0/Download');
          var savePath = dir.path;
          final pdfFile = File('${savePath}/${widget.date}_${widget.userName}.pdf');
          await ref.writeToFile(pdfFile);
          Fluttertoast.showToast(msg: "PDF Saved Successfully",backgroundColor: Colors.green,textColor: Colors.white);
      }else if(Platform.isIOS){
        final response = await http.get(Uri.parse(widget.pdfUrl));
        // response.
     }

   }catch (e){
     Fluttertoast.showToast(msg: "Something Went Wrong, Unable to Save PDF");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Expanded(
            child: Container(
              height: MediaQuery.of(context).size.height,
              child: _isLoading
                  ? Center(
                      child: CircularProgressIndicator(
                      strokeWidth: 0.5,
                    ))
                  : (_scannedDocument == null)
                      ? Text("No data")
                      : PDFViewerCachedFromUrl(
                url:widget.pdfUrl ,
              ),
              // PDFViewer(
              //             document: _scannedDocument!,
              //           ),
            ),
          ),
          
          InkWell(
              onTap: (){
                downloadPDF ();
              },
              child: Padding(
                padding: const EdgeInsets.only(bottom: 15),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.file_download_outlined),
                    const SizedBox(width: 8,),
                    Text('Save PDF'),
                  ],
                ),
              ))

        ],
      ),
    );
  }
}
class PDFViewerCachedFromUrl extends StatelessWidget {
  const PDFViewerCachedFromUrl({Key? key, required this.url}) : super(key: key);

  final String url;

  @override
  Widget build(BuildContext context) {
    return
      const PDF(
       swipeHorizontal: true,

       ).cachedFromUrl(
        url,
      //  placeholder: (double progress) => Center(child: Text('$progress %')),
        errorWidget: (dynamic error) => Center(child: Text(error.toString())),
      );

  }
}