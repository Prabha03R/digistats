import 'dart:io';
import 'package:advance_pdf_viewer2/advance_pdf_viewer.dart';
import 'package:camera/camera.dart';
import 'package:docmentscan/cubits/getemployee_cubit.dart';
import 'package:docmentscan/models/admindata.dart';
import 'package:draggable_scrollbar/draggable_scrollbar.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'dart:io' as io;
import 'package:pdf/widgets.dart' as pw;
import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;
import 'package:pdf_compressor/pdf_compressor.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';

import '../consts/app_colors.dart';
import '../consts/app_sizes.dart';
import '../consts/app_styles.dart';
import '../controllers/filename.dart';
import '../cubits/add_document_cubit/adddocument_cubit.dart';
import '../cubits/getadmindata_cubit.dart';
import '../models/getemployee.dart';
import 'helpers.dart';

class ScanPage extends StatefulWidget {
  const ScanPage({
    super.key,
    required this.userType,
  });

  final String userType;

  @override
  State<ScanPage> createState() => _ScanPageState();
}

class _ScanPageState extends State<ScanPage> {
  final userdata = FirebaseAuth.instance.currentUser;
  String phno='';

  @override
  void initState() {

    super.initState();
    if (widget.userType == "employee") {
      getData();
    }else{
      GetadmindataState state = context.read<GetadmindataCubit>().state;
      if (state is! Getadmindataloaded) {
        context.read<GetadmindataCubit>().getadminData();
      }
    }


    // openPdfScanner(context);
  }
  @override
  void getData()async{
    final SharedPreferences prefs =await SharedPreferences.getInstance();
    phno= prefs.getString('phno')??'';
    context.read<GetemployeeCubit>().getUseData(phno: phno);
  }
  PDFDocument? _scannedDocument;
  io.File? _scannedDocumentFile;
  io.File? _scannedImage;
  List<XFile> images = [];
  bool isShowDocmentView = false;


// Upload the local file to Firebase Storage

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: BlocBuilder<AdddocumentCubit, AdddocumentState>(
        builder: (context, submitDocState) {

          if (submitDocState is AdddocumentAdded) {
            String userType = submitDocState.userType;
            if (userType == "emp") {
              String phno = submitDocState.phonNo;
              context.read<GetemployeeCubit>().getUseData(phno: phno ?? "");
            } else {
              context.read<GetadmindataCubit>().getadminDatasilent();
            }
            context.read<AdddocumentCubit>().resetCubit();
          }
          if (isShowDocmentView) {
            return DocmentViewScreen(images);
          }
          return Center(
              child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              if (_scannedDocument != null || _scannedImage != null) ...[
                if (_scannedImage != null)
                  Image.file(_scannedImage!,
                      width: 300, height: 300, fit: BoxFit.contain),
                if (_scannedDocument != null)
                  Expanded(
                      child: PDFViewer(
                    document: _scannedDocument!,
                  )),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                      _scannedDocumentFile?.path ?? _scannedImage?.path ?? ''),
                ),
              ],
              Center(
                child: Builder(builder: (context) {
                  return Column(
                    // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      ElevatedButton(
                          onPressed:() async {
                            File? takeFile = await getImage(ImageSource.camera);
                            if (takeFile == null) {
                              return;
                            }
                            XFile xFile = XFile(takeFile.path);
                            images.add(xFile);

                            setState(() {});
                          },
                          child: Text(
                            "PDF Scan",
                            style: Theme.of(context)
                                .textTheme
                                .bodySmall
                                ?.apply(color: Colors.black, fontSizeDelta: 2),
                          )),
                      userdata?.email == null
                          ? BlocBuilder<GetemployeeCubit, GetemployeeState>(
                              builder: (context, empstate) {
                                if (empstate is Getemployeeloaded) {
                                  List<Employeedetails> empdetails = empstate
                                      .props.first as List<Employeedetails>;

                                  return ElevatedButton(
                                      onPressed: () async {
                                        if (_scannedDocumentFile != null) {
                                          context
                                              .read<AdddocumentCubit>()
                                              .addDocument(
                                                  scannedDocumentFile:
                                                      _scannedDocumentFile,
                                                  empdetails: empdetails,
                                                  userType: "emp");
                                          // if (downloadURL != null) {
                                          //   print('Document uploaded to Firebase: $downloadURL');
                                          //   final SharedPreferences prefs =await SharedPreferences.getInstance();
                                          //   String? phno= prefs.getString('phno');
                                          //   Employeedetails curEmp= empdetails.firstWhere((element) => element.phno==phno);
                                          //   var li=curEmp.docs??[];
                                          //   li.add(downloadURL);
                                          //   FirebaseFirestore.instance.collection('employee').doc(curEmp.id).set(
                                          //       {
                                          //         "documents":curEmp.docs,
                                          //         "senderName":'${curEmp.lastname} ${curEmp.firstname}',
                                          //         "date": "${DateFormat('dd-MM-yyyy').format(DateTime.now())}"
                                          //       },
                                          //       SetOptions(merge: true)
                                          //   ).then((value) {
                                          //     context.read<GetemployeeCubit>().getUseData(phno: phno??"");
                                          //     Fluttertoast.showToast(msg: "Pdf saved successfully",backgroundColor: Colors.green);
                                          //   });
                                          //   // Handle the downloadURL as needed
                                          // } else {
                                          //   // Handle the case when uploading to Firebase failed or no scanned document is available
                                          //   print('Uploading document to Firebase failed or no scanned document available.');
                                          // }
                                        } else {
                                          Fluttertoast.showToast(
                                              msg: "Kindly Scan Document");
                                        }
                                      },
                                      child: submitDocState
                                              is AdddocumentLoading
                                          ? Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                SizedBox(
                                                    height: 24,
                                                    width: 24,
                                                    child:
                                                        CircularProgressIndicator(
                                                      strokeWidth: 0.7,
                                                    )),
                                                const SizedBox(
                                                  width: 4,
                                                ),
                                                Text(
                                                  "Save Pdf",
                                                  style: Theme.of(context)
                                                      .textTheme
                                                      .bodySmall
                                                      ?.apply(
                                                          color: Colors.black,
                                                          fontSizeDelta: 2),
                                                ),
                                              ],
                                            )
                                          : Text(
                                              "Save Pdf",
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .bodySmall
                                                  ?.apply(
                                                      color: Colors.black,
                                                      fontSizeDelta: 2),
                                            ));
                                } else {
                                  return Container();
                                }
                              },
                            )
                          : BlocBuilder<GetadmindataCubit, GetadmindataState>(
                              builder: (context, admminstate) {
                                if (admminstate is Getadmindataloaded) {
                                  List<Admindata> admindata = admminstate
                                      .props.first as List<Admindata>;
                                  Admindata curadmin = admindata.firstWhere(
                                      (element) =>
                                          element.email == userdata?.email);

                                  return ElevatedButton(
                                      onPressed: () async {
                                        if (_scannedDocumentFile != null) {
                                          context
                                              .read<AdddocumentCubit>()
                                              .addDocument(
                                                  scannedDocumentFile:
                                                      _scannedDocumentFile,
                                                  curadmin: curadmin,
                                                  userType: "admin");
                                          // if (downloadURL != null) {
                                          //
                                          //   FirebaseFirestore.instance.collection('users').doc(curadmin.id).set({
                                          //     "sendDocuments":FieldValue.arrayUnion([{
                                          //       "pdfDocument": downloadURL,
                                          //       "senderName":userdata?.displayName ,
                                          //       "date": "${DateFormat('dd-MM-yyyy').format(DateTime.now())}"
                                          //     }])
                                          //   },
                                          //       SetOptions(merge : true)
                                          //     //.then((value) {
                                          //     //   FirebaseFirestore.instance.collection("users").doc(userdata?.uid).update({
                                          //     //     "documents":FieldValue.arrayRemove([widget.pdfDocument]) });
                                          //     //   Fluttertoast.showToast(msg: "PDF Send Successfully",backgroundColor: Colors.green,textColor: Colors.white);
                                          //     //   Navigator.pop(context);
                                          //
                                          //
                                          //   ).then((value) {
                                          //     context.read<GetadmindataCubit>().getadminDatasilent();
                                          //     Fluttertoast.showToast(msg: "Pdf saved successfully",backgroundColor: Colors.green);
                                          //
                                          //   });
                                          //
                                          // }else{
                                          //
                                          // }
                                        } else {
                                          Fluttertoast.showToast(
                                              msg: "Kindly Scan Document");
                                        }
                                      },
                                      child: submitDocState
                                              is AdddocumentLoading
                                          ? Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                SizedBox(
                                                    height: 24,
                                                    width: 24,
                                                    child:
                                                        CircularProgressIndicator(
                                                      strokeWidth: 0.7,
                                                    )),
                                                const SizedBox(
                                                  width: 4,
                                                ),
                                                Text(
                                                  "Save Pdf",
                                                  style: Theme.of(context)
                                                      .textTheme
                                                      .bodySmall
                                                      ?.apply(
                                                          color: Colors.black,
                                                          fontSizeDelta: 2),
                                                ),
                                              ],
                                            )
                                          : Text(
                                              "Save Pdf",
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .bodySmall
                                                  ?.apply(
                                                      color: Colors.black,
                                                      fontSizeDelta: 2),
                                            ));
                                } else {
                                  return Container();
                                }
                              },
                            )
                    ],
                  );
                }),
              ),
            ],
          ));
        },
      ),
      // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}
class DocmentViewScreen extends StatefulWidget {
  const DocmentViewScreen(this.images, {Key? key}) : super(key: key);

  final List<XFile> images;

  @override
  State<DocmentViewScreen> createState() => _DocmentViewScreenState();
}

class _DocmentViewScreenState extends State<DocmentViewScreen> {
  final ScrollController controller = ScrollController();
  bool isShowShare = false;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(lang("PDF")),
        actions: [
          InkWell(
            onTap: () async {

              File file = await createFile();
              fileNameDialog('PDF', file.path, 'document');

            },
            child: Padding(
              padding: const EdgeInsets.symmetric(
                vertical: 15,
                horizontal: 20,
              ),
              child: Text(
                lang('Save'),
                style: AppStyles.text.copyWith(
                  fontSize: AppSizes.size14,
                  color: AppColors.text,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          )
        ],
      ),
      backgroundColor: Colors.grey.shade100,
      body: Container(
        margin: const EdgeInsets.symmetric(
          horizontal: 5,
        ),
        child: DraggableScrollbar.semicircle(
          labelTextBuilder: (offset) {
            final int currentItem = (controller.hasClients
                ? (controller.offset /
                controller.position.maxScrollExtent *
                widget.images.length)
                .floor()
                : 0) +
                1;

            return Text("$currentItem");
          },
          labelConstraints: const BoxConstraints.tightFor(
            width: 80.0,
            height: 30.0,
          ),
          controller: controller,
          child: ListView.builder(
            padding: const EdgeInsets.only(top: 10),
            controller: controller,
            itemCount: widget.images.length,
            itemBuilder: (context, index) {
              return Stack(
                children: [
                  Container(
                    width: double.infinity,
                    height: AppSizes.newSize(50),
                    margin: const EdgeInsets.only(
                      left: 5,
                      right: 5,
                      bottom: 10,
                    ),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 10,
                    ),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.2),
                          spreadRadius: 1,
                          blurRadius: 3,
                          offset: const Offset(0, 1),
                        ),
                      ],
                    ),
                    child: Image.file(
                      File(widget.images[index].path),
                    ),
                  ),
                  Positioned(
                    top: 15,
                    right: 15,
                    child: Container(
                      height: 30,
                      width: 30,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: AppColors.primaryColor,
                        borderRadius: BorderRadius.circular(100),
                      ),
                      child: Text(
                        (index + 1).toString(),
                        style: AppStyles.heading.copyWith(
                          color: AppColors.text,
                          fontSize: AppSizes.size14,
                        ),
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
      bottomNavigationBar: Container(
        height: 80,
        width: double.infinity,
        color: Colors.grey,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            if (!isShowShare)
              InkWell(
                onTap: () async {
                  setState(() {
                    isShowShare = true;
                  });
                },
                child: Container(
                  padding: const EdgeInsets.all(5),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const FaIcon(
                        FontAwesomeIcons.shareNodes,
                        color: AppColors.text,
                      ),
                      const SizedBox(height: 5),
                      Text(
                        lang('Share'),
                        style: AppStyles.heading.copyWith(
                          color: AppColors.text.withOpacity(0.7),
                          fontSize: AppSizes.size14,
                        ),
                      ),
                    ],
                  ),
                ),
              )
            else ...[
              InkWell(
                onTap: () async {
                  File? pdfFile = await createFile();

                  await Share.shareXFiles([
                    XFile(pdfFile.path),
                  ]);
                },
                child: Container(
                  padding: const EdgeInsets.all(5),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const FaIcon(
                        FontAwesomeIcons.shareNodes,
                        color: AppColors.text,
                      ),
                      const SizedBox(height: 5),
                      Text(
                        lang('Original Size'),
                        style: AppStyles.heading.copyWith(
                          color: AppColors.text.withOpacity(0.7),
                          fontSize: AppSizes.size14,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              InkWell(
                onTap: () async {
                  setState(() {
                    isShowShare = false;
                  });
                },
                child: Container(
                  padding: const EdgeInsets.all(5),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: const [
                      FaIcon(
                        FontAwesomeIcons.xmark,
                        color: AppColors.text,
                      ),
                    ],
                  ),
                ),
              ),
              InkWell(
                onTap: () async {
                  compressPDF();
                },
                child: Container(
                  padding: const EdgeInsets.all(5),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const FaIcon(
                        FontAwesomeIcons.shareNodes,
                        color: AppColors.text,
                      ),
                      const SizedBox(height: 5),
                      Text(
                        lang('Compress Size'),
                        style: AppStyles.heading.copyWith(
                          color: AppColors.text.withOpacity(0.7),
                          fontSize: AppSizes.size14,
                        ),
                      ),
                    ],
                  ),
                ),
              )
            ],
          ],
        ),
      ),
    );
  }

  Future<File> createFile() async {
    var pdf = pw.Document();

    widget.images.forEach((element) async {
      var file = File(element.path);
      final img = pw.MemoryImage(file.readAsBytesSync());
      pdf.addPage(
        pw.Page(
          pageFormat: PdfPageFormat.a4,
          build: (pw.Context contex) {
            return pw.Center(child: pw.Image(img));
          },
        ),
      );
    });

    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/document.pdf');
    await file.writeAsBytes(await pdf.save());

    return file;
  }

  compressPDF() async {
    try {
      final dir = await getTemporaryDirectory();
      File pdfFile = await createFile();
      final compressPdfFile = File('${dir.path}/compress_document.pdf');
      await PdfCompressor.compressPdfFile(
        pdfFile.path,
        compressPdfFile.path,
        CompressQuality.HIGH,
      );

      await Share.shareXFiles([
        XFile(compressPdfFile.path),
      ]);
    } catch (e) {
      dd(e.toString());
    }
  }
}
