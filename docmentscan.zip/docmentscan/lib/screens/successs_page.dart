import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

class Sucesspage extends StatelessWidget {
  const Sucesspage({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(23), color: Colors.white),
      height: 450,
      width: 302,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const SizedBox(
            height: 62,
          ),
          SvgPicture.asset('assets/reset.svg'),
          const SizedBox(
            height: 30,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Reset Password',
                style: Theme.of(context).textTheme.bodyLarge?.apply(
                    fontSizeDelta: 4, color: Color.fromRGBO(15, 133, 219, 1)),
              ),
            ],
          ),
          // const SizedBox(height: 10,),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('Link send!',
                  style: Theme.of(context).textTheme.bodyLarge?.apply(
                      fontSizeDelta: 4,
                      color: Color.fromRGBO(15, 133, 219, 1))),
            ],
          ),
          const SizedBox(
            height: 24,
          ),
          Padding(
            padding: const EdgeInsets.only(left: 16, right: 16),
            child: Text(
              'Kindly check Your Email and reset your password',
              style: Theme.of(context).textTheme.bodySmall?.apply(
                    fontSizeDelta: 2,
                    color: Color.fromRGBO(37, 37, 37, 1),
                  ),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(
            height: 16,
          ),
          InkWell(
            onTap: () {
              Navigator.pushReplacementNamed(context, 'adminlogin');
            },
            child: Container(
              height: 44,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(6),
                  color: Color.fromRGBO(15, 133, 219, 1)),
              margin: EdgeInsets.only(right: 52, left: 52),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Go to home',
                    style: Theme.of(context).textTheme.headlineSmall?.apply(
                        color: Color.fromRGBO(255, 255, 255, 1),
                        fontSizeDelta: 1),
                  ),

                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
