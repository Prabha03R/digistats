import 'package:docmentscan/cubits/signin_cubit.dart';
import 'package:docmentscan/screens/profile.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'forget_password.dart';

class Adminlogin extends StatefulWidget {
  const Adminlogin({super.key});

  @override
  State<Adminlogin> createState() => _AdminloginState();
}

class _AdminloginState extends State<Adminlogin> {
  final formKey = GlobalKey<FormState>();
  TextEditingController emailcontroller = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  late bool _passwordVisible;

  @override
  void initState() {
    _passwordVisible = false;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromRGBO(15, 133, 219, 1),
      body: Form(
        key: formKey,
        child: BlocBuilder<SigninCubit, SigninState>(
          builder: (context, adminstate) {
            if (adminstate is Signedin) {
              Future.delayed(Duration.zero, () {
                // Navigator.pushReplacement(
                //   context,
                //   MaterialPageRoute(
                //       builder: (context) => Profile(userType: 'admin')),
                // );
                Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(
                        builder: (context) => Profile(userType: 'admin')),
                    (Route<dynamic> route) => false);
                context.read<SigninCubit>().reset();
              });
            } else if (adminstate is Signinerror) {
              emailcontroller.clear();
              passwordController.clear();
              context.read<SigninCubit>().reset();
            }
            return SingleChildScrollView(
              child: Column(
                children: [
                  Stack(
                    children: [
                      Container(
                        height: 484,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(40),
                            bottomRight: Radius.circular(40),
                          ),
                          color: Color.fromRGBO(66, 155, 237, 1),
                        ),
                      ),
                      Container(
                        // height: 478,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(46),
                            bottomRight: Radius.circular(46),
                          ),
                          color: Colors.white,
                        ),

                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const SizedBox(
                              height: 82,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  'Signin',
                                  style: Theme.of(context).textTheme.bodyLarge,
                                ),
                              ],
                            ),
                            const SizedBox(
                              height: 58,
                            ),
                            Container(
                              padding: EdgeInsets.only(left: 22, right: 22),
                              child: TextFormField(
                                controller: emailcontroller,
                                style: Theme.of(context)
                                    .textTheme
                                    .bodySmall
                                    ?.apply(
                                        color: Color.fromRGBO(102, 100, 100, 1),
                                        fontSizeDelta: 2),
                                decoration: InputDecoration(
                                  border: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: Color.fromRGBO(
                                              217, 212, 218, 1))),
                                  enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: Color.fromRGBO(
                                              217, 212, 218, 1))),
                                  focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: Color.fromRGBO(
                                              217, 212, 218, 1))),
                                  focusedErrorBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: Color.fromRGBO(
                                              217, 212, 218, 1))),
                                  errorBorder: OutlineInputBorder(
                                      borderSide:
                                          BorderSide(color: Colors.red)),
                                  labelStyle: Theme.of(context)
                                      .textTheme
                                      .bodySmall
                                      ?.apply(
                                        color: Color.fromRGBO(102, 100, 100, 1),
                                      ),
                                  prefixIcon: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      const SizedBox(
                                        width: 8,
                                      ),
                                      Icon(Icons.email_outlined,
                                          size: 18,
                                          color: Color.fromRGBO(0, 8, 66, 1)),
                                      Container(
                                        width: 1,
                                        height: 12,
                                        color: Color.fromRGBO(102, 100, 100, 1),
                                        margin:
                                            EdgeInsets.only(left: 8, right: 8),
                                      )
                                    ],
                                  ),
                                  hintText: 'Enter Your Email',
                                  hintStyle: Theme.of(context)
                                      .textTheme
                                      .bodySmall
                                      ?.apply(
                                          color:
                                              Color.fromRGBO(102, 100, 100, 1),
                                          fontSizeDelta: 2),
                                  labelText: 'Email',
                                ),
                                onSaved: (String? value) {},
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return 'Please enter your email';
                                  }
                                  return null;
                                },
                              ),
                            ),
                            const SizedBox(
                              height: 40,
                            ),
                            Container(
                              padding: EdgeInsets.only(left: 22, right: 22),
                              child: TextFormField(
                                controller: passwordController,
                                obscureText: !_passwordVisible,
                                style: Theme.of(context)
                                    .textTheme
                                    .bodySmall
                                    ?.apply(
                                        color: Color.fromRGBO(102, 100, 100, 1),
                                        fontSizeDelta: 2),
                                decoration: InputDecoration(
                                  border: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: Color.fromRGBO(
                                              217, 212, 218, 1))),
                                  enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: Color.fromRGBO(
                                              217, 212, 218, 1))),
                                  focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: Color.fromRGBO(
                                              217, 212, 218, 1))),
                                  focusedErrorBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: Color.fromRGBO(
                                              217, 212, 218, 1))),
                                  labelStyle: Theme.of(context)
                                      .textTheme
                                      .bodySmall
                                      ?.apply(
                                        color: Color.fromRGBO(102, 100, 100, 1),
                                      ),
                                  suffixIcon: IconButton(
                                    icon: Icon(
                                      // Based on passwordVisible state choose the icon
                                      _passwordVisible
                                          ? Icons.visibility
                                          : Icons.visibility_off,
                                      size: 16,
                                      color: Color.fromRGBO(153, 153, 153, 1),
                                    ),
                                    onPressed: () {
                                      setState(() {
                                        _passwordVisible = !_passwordVisible;
                                      });
                                    },
                                  ),
                                  prefixIcon: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      const SizedBox(
                                        width: 8,
                                      ),
                                      Icon(Icons.lock_outline_rounded,
                                          size: 18,
                                          color: Color.fromRGBO(0, 8, 66, 1)),
                                      Container(
                                        width: 1,
                                        height: 12,
                                        color: Color.fromRGBO(102, 100, 100, 1),
                                        margin:
                                            EdgeInsets.only(left: 8, right: 8),
                                      )
                                    ],
                                  ),
                                  hintText: 'Enter Your Password',
                                  hintStyle: Theme.of(context)
                                      .textTheme
                                      .bodySmall
                                      ?.apply(
                                          color:
                                              Color.fromRGBO(102, 100, 100, 1),
                                          fontSizeDelta: 2),
                                  labelText: 'Password',
                                ),
                                onSaved: (String? value) {},
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return 'Please enter your password';
                                  }
                                  return null;
                                },
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(
                                  right: 24, top: 8, bottom: 32),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  InkWell(
                                    onTap: () {
                                      Navigator.pushReplacement(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                Forgetpassword()),
                                      );
                                    },
                                    child: Text(
                                      'Forget Password?',
                                      style: Theme.of(context)
                                          .textTheme
                                          .bodySmall
                                          ?.apply(
                                              fontSizeDelta: -2,
                                              color: Color.fromRGBO(
                                                  58, 58, 58, 1)),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            InkWell(
                              onTap: () async{
                                if (formKey.currentState!.validate()) {
                                  context.read<SigninCubit>().SignIn(
                                      email: emailcontroller.value.text,
                                      password: passwordController.value.text);

                                } else {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                        content: Text('Please fill all field')),
                                  );
                                }
                              },
                              child: Container(
                                  height: 46,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(12),
                                      color: Color.fromRGBO(15, 133, 219, 1)),
                                  margin: EdgeInsets.only(right: 22, left: 22),
                                  child: (adminstate is Signinloading)
                                      ? Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            SizedBox(
                                                height: 24,
                                                width: 24,
                                                child:
                                                    CircularProgressIndicator(
                                                  strokeWidth: 0.7,
                                                )),
                                            const SizedBox(
                                              width: 4,
                                            ),
                                            Text(
                                              'Login',
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .bodyMedium
                                                  ?.apply(
                                                      color: Color.fromRGBO(
                                                          255, 255, 255, 1)),
                                            ),
                                          ],
                                        )
                                      : Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Text(
                                              'Login',
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .bodyMedium
                                                  ?.apply(
                                                      color: Color.fromRGBO(
                                                          255, 255, 255, 1)),
                                            ),
                                          ],
                                        )),
                            ),
                            const SizedBox(
                              height: 46,
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 100,
                  ),
                  Column(
                    children: [
                      Text(
                        'Scanning ',
                        style: Theme.of(context)
                            .textTheme
                            .headlineLarge
                            ?.apply(color: Colors.white),
                      ),
                      Text(
                        'Application',
                        style: Theme.of(context)
                            .textTheme
                            .headlineLarge
                            ?.apply(color: Colors.white),
                      ),
                    ],
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
