import 'package:docmentscan/screens/scannedfiles.dart';
import 'package:docmentscan/screens/scanning.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:io' as io;
import '../cubits/getemployee_cubit.dart';
import 'adminscannedfiles.dart';
import 'common_login.dart';
import 'manage_admin.dart';
import 'manage_employee.dart';
import 'newscreen.dart';

class Profile extends StatefulWidget {
  const Profile({
    super.key,
    required this.userType,
  });

  final String userType;

  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  final userdata = FirebaseAuth.instance.currentUser;

  int _selectedIndex = 0;
  static const TextStyle optionStyle =
      TextStyle(fontSize: 30, fontWeight: FontWeight.bold);
  static List<Widget> _adminwidgetOptions = <Widget>[
    ScanPage(userType: 'admin'),
    Manageemploye(),
    Manageadmin(),
    Adminscanfiles(),
    Text(
      'Settings',
      style: optionStyle,
    ),
  ];
  static List<Widget> _EMPwidgetOptions = <Widget>[
    ScanPage(userType:'employee',),
    MyGridView(),
    Text(
      'Settings',
      style: optionStyle,
    ),
  ];

  List admintitle = [
    'Scanning',
    'Manage Employee',
    'Manage Admin',
    'Scanned Files',
    'Settings',
  ];
  List emptitle = [
    'Scanning',
    'Scanned Files',
    'Settings',
  ];

  void _onItemTapped(int index) {
    setState(() {
      print('----$_selectedIndex');

      _selectedIndex = index;
    });
  }

  String imagePath = '';
  String userName = '';
  String userEmail = '';
  String userPhonNO = '';

  @override
  void initState() {
    if (widget.userType == "admin") {
      imagePath = userdata?.photoURL ?? "";
      userName = userdata?.displayName ?? "";
      userEmail = userdata?.email ?? "";
    } else {
      GetemployeeState empState = context.read<GetemployeeCubit>().state;
      if (empState is Getemployeeloaded) {
        // context.read<GetemployeeCubit>().getemployeeData();
        imagePath = empState.employeedetails[0].image ?? "";
        userName =
            "${empState.employeedetails[0].firstname ?? ""} ${empState.employeedetails[0].lastname ?? ""}";
        userPhonNO = empState.employeedetails[0].phno ?? "";
      }
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    print("0000${imagePath}");
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color.fromRGBO(66, 155, 237, 1),
        iconTheme: IconThemeData(color: Colors.white),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                (widget.userType == "admin")
                    ? Text(
                        admintitle[_selectedIndex],
                        style: Theme.of(context).textTheme.headlineSmall?.apply(
                              color: Color.fromRGBO(255, 255, 255, 1),
                            ),
                      )
                    : Text(
                        emptitle[_selectedIndex],
                        style: Theme.of(context).textTheme.headlineSmall?.apply(
                              color: Color.fromRGBO(255, 255, 255, 1),
                            ),
                      ),
              ],
            ),
            Icon(
              Icons.notifications,
              color: Colors.white,
            ),
          ],
        ),
      ),
      drawer: (widget.userType == "admin")
          ? Drawer(
              backgroundColor: Color.fromRGBO(215, 236, 255, 1),
              child: ListView(
                // Important: Remove any padding from the ListView.
                padding: EdgeInsets.zero,
                children: [
                  DrawerHeader(
                    decoration: BoxDecoration(
                      boxShadow: [
                        BoxShadow(
                            spreadRadius: 0,
                            blurRadius: 3,
                            color: Color.fromRGBO(0, 0, 0, 0.1))
                      ],
                    ),
                    child: Row(
                      children: [
                        imagePath == ""
                            ? Image.asset('assets/profile.png')
                            : CircleAvatar(
                                backgroundColor: Colors.transparent,
                                radius: 36,
                                onBackgroundImageError:
                                    (exception, stackTrace) => Image.asset(
                                  'assets/profile.png',
                                  height: 50,
                                  width: 50,
                                ),
                                backgroundImage: NetworkImage(imagePath),
                              ),
                        const SizedBox(
                          width: 16,
                        ),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '${userName}',
                              style: Theme.of(context).textTheme.titleSmall,
                            ),
                            Text(
                              "${userEmail}",
                              style: Theme.of(context).textTheme.bodySmall,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  ListTile(
                    title: _selectedIndex == 0
                        ? Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(4),
                              color: Color.fromRGBO(15, 133, 219, 1),
                            ),
                            padding:
                                EdgeInsets.only(left: 14, top: 12, bottom: 12),
                            child: Row(
                              children: [
                                SvgPicture.asset('assets/scan.svg'),
                                const SizedBox(
                                  width: 14,
                                ),
                                Text('Scanning',
                                    style: Theme.of(context)
                                        .textTheme
                                        .titleSmall
                                        ?.apply(color: Colors.white)),
                              ],
                            ),
                          )
                        : Row(
                            children: [
                              SvgPicture.asset(
                                'assets/scan.svg',
                                color: Colors.black,
                              ),
                              const SizedBox(
                                width: 14,
                              ),
                              Text('Scanning',
                                  style: Theme.of(context)
                                      .textTheme
                                      .titleSmall
                                      ?.apply(
                                        color: Color.fromRGBO(49, 49, 49, 1),
                                      ))
                            ],
                          ),
                    selected: _selectedIndex == 0,
                    onTap: () {
                      _onItemTapped(0);
                      Navigator.pop(context);
                    },
                  ),
                  ListTile(
                    title: _selectedIndex == 1

                        ? Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(4),
                              color: Color.fromRGBO(15, 133, 219, 1),
                            ),
                            padding:
                                EdgeInsets.only(left: 14, top: 12, bottom: 12),
                            child: Row(
                              children: [
                                SvgPicture.asset(
                                  'assets/person.svg',
                                  color: Colors.white,
                                ),
                                const SizedBox(
                                  width: 14,
                                ),
                                Text('Manage Employee',
                                    style: Theme.of(context)
                                        .textTheme
                                        .titleSmall
                                        ?.apply(color: Colors.white)),
                              ],
                            ),
                          )
                        : Row(
                            children: [
                              SvgPicture.asset(
                                'assets/person.svg',
                              ),
                              const SizedBox(
                                width: 14,
                              ),
                              Text(
                                'Manage Employee',
                                style: Theme.of(context).textTheme.titleSmall,
                              ),
                            ],
                          ),
                    selected: _selectedIndex == 1,
                    onTap: () {
                      _onItemTapped(1);
                      Navigator.pop(context);
                    },
                  ),
                  ListTile(
                    title: _selectedIndex == 2
                        ? Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(4),
                              color: Color.fromRGBO(15, 133, 219, 1),
                            ),
                            padding:
                                EdgeInsets.only(left: 14, top: 12, bottom: 12),
                            child: Row(
                              children: [
                                SvgPicture.asset(
                                  'assets/person.svg',
                                  color: Colors.white,
                                ),
                                const SizedBox(
                                  width: 14,
                                ),
                                Text('Manage Admin',
                                    style: Theme.of(context)
                                        .textTheme
                                        .titleSmall
                                        ?.apply(color: Colors.white)),
                              ],
                            ),
                          )
                        : Row(
                            children: [
                              SvgPicture.asset(
                                'assets/person.svg',
                              ),
                              const SizedBox(
                                width: 14,
                              ),
                              Text(
                                'Manage Admin',
                                style: Theme.of(context).textTheme.titleSmall,
                              ),
                            ],
                          ),
                    selected: _selectedIndex == 2,
                    onTap: () {
                      _onItemTapped(2);
                      Navigator.pop(context);
                    },
                  ),
                  ListTile(
                    title: _selectedIndex == 3
                        ? Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(4),
                              color: Color.fromRGBO(15, 133, 219, 1),
                            ),
                            padding:
                                EdgeInsets.only(left: 14, top: 12, bottom: 12),
                            child: Row(
                              children: [
                                SvgPicture.asset('assets/scan.svg'),
                                const SizedBox(
                                  width: 14,
                                ),
                                Text('Scanned Files',
                                    style: Theme.of(context)
                                        .textTheme
                                        .titleSmall
                                        ?.apply(color: Colors.white)),
                              ],
                            ),
                          )
                        : Row(
                            children: [
                              SvgPicture.asset(
                                'assets/scan.svg',
                                color: Colors.black,
                              ),
                              const SizedBox(
                                width: 14,
                              ),
                              Text(
                                'Scanned Files',
                                style: Theme.of(context).textTheme.titleSmall,
                              ),
                            ],
                          ),
                    selected: _selectedIndex == 3,
                    onTap: () {
                      _onItemTapped(3);
                      Navigator.pop(context);
                    },
                  ),
                  ListTile(
                    title: _selectedIndex == 4
                        ? Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(4),
                              color: Color.fromRGBO(15, 133, 219, 1),
                            ),
                            padding:
                                EdgeInsets.only(left: 14, top: 12, bottom: 12),
                            child: Row(
                              children: [
                                SvgPicture.asset(
                                  'assets/settings.svg',
                                  color: Colors.white,
                                ),
                                const SizedBox(
                                  width: 14,
                                ),
                                Text('Settings',
                                    style: Theme.of(context)
                                        .textTheme
                                        .titleSmall
                                        ?.apply(color: Colors.white)),
                              ],
                            ),
                          )
                        : Row(
                            children: [
                              SvgPicture.asset(
                                'assets/settings.svg',
                              ),
                              const SizedBox(
                                width: 14,
                              ),
                              Text(
                                'Settings',
                                style: Theme.of(context).textTheme.titleSmall,
                              ),
                            ],
                          ),
                    selected: _selectedIndex == 4,
                    onTap: () {
                      _onItemTapped(4);
                      Navigator.pop(context);
                    },
                  ),
                  const SizedBox(
                    height: 210,
                  ),
                  Container(
                    height: 1,
                    color: Color.fromRGBO(217, 217, 217, 1),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 32, top: 22),
                    child: Row(
                      children: [
                        Icon(Icons.logout_outlined),
                        const SizedBox(
                          width: 12,
                        ),
                        InkWell(
                            onTap: () async{
                              print(widget.userType);
                              final SharedPreferences prefs =await SharedPreferences.getInstance();

                                // delete email
                                prefs.remove("email");
                                prefs.remove("phno");
                                FirebaseAuth.instance.signOut();
                                Navigator.of(context).pushAndRemoveUntil(
                                    MaterialPageRoute(
                                        builder: (context) => Commonlogin()),
                                        (Route<dynamic> route) => false);

                            },
                            child: Text(
                              'Logout',
                              style: Theme.of(context)
                                  .textTheme
                                  .bodySmall
                                  ?.apply(fontSizeDelta: 2),
                            )),
                        // InkWell(
                        //
                        //     onTap: () {
                        //       print(widget.userType);
                        //       if (widget.userType == 'admin') {
                        //         FirebaseAuth.instance.signOut();
                        //         Navigator.pushReplacement(
                        //             context,
                        //             MaterialPageRoute(
                        //               builder: (context) => Commonlogin(),
                        //             ));
                        //       } else {
                        //         context.read<GetemployeeCubit>().reset();
                        //         Navigator.pushReplacement(
                        //             context,
                        //             MaterialPageRoute(
                        //               builder: (context) => Commonlogin(),
                        //             ));
                        //       }
                        //     },
                        //     child: Text(
                        //       'Logout',
                        //       style: Theme.of(context)
                        //           .textTheme
                        //           .bodySmall
                        //           ?.apply(fontSizeDelta: 2),
                        //     )),
                      ],
                    ),
                  ),
                ],
              ))
          : Drawer(
              backgroundColor: Color.fromRGBO(215, 236, 255, 1),
              child: ListView(
                // Important: Remove any padding from the ListView.
                padding: EdgeInsets.zero,
                children: [
                  DrawerHeader(
                    child: Row(
                      children: [
                        imagePath == ""
                            ? Image.asset('assets/profile.png')
                            : CircleAvatar(
                                backgroundColor: Colors.transparent,
                                radius: 36,
                                onBackgroundImageError:
                                    (exception, stackTrace) => Image.asset(
                                  'assets/profile.png',
                                  height: 50,
                                  width: 50,
                                ),
                                backgroundImage: NetworkImage(imagePath),
                              ),
                        const SizedBox(
                          width: 16,
                        ),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '${userName}',
                              style: Theme.of(context).textTheme.titleSmall,
                            ),
                            Text(
                              "${userPhonNO}",
                              style: Theme.of(context).textTheme.bodySmall,
                            )
                          ],
                        ),
                      ],
                    ),
                  ),
                  ListTile(
                    title: _selectedIndex == 0
                        ? Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(4),
                              color: Color.fromRGBO(15, 133, 219, 1),
                            ),
                            padding:
                                EdgeInsets.only(left: 14, top: 12, bottom: 12),
                            child: Row(
                              children: [
                                SvgPicture.asset('assets/scan.svg'),
                                const SizedBox(
                                  width: 14,
                                ),
                                Text('Scanning',
                                    style: Theme.of(context)
                                        .textTheme
                                        .titleSmall
                                        ?.apply(color: Colors.white)),
                              ],
                            ),
                          )
                        : Row(
                            children: [
                              SvgPicture.asset(
                                'assets/scan.svg',
                                color: Colors.black,
                              ),
                              const SizedBox(
                                width: 14,
                              ),
                              Text('Scanning',
                                  style: Theme.of(context)
                                      .textTheme
                                      .titleSmall
                                      ?.apply(
                                        color: Color.fromRGBO(49, 49, 49, 1),
                                      ))
                            ],
                          ),
                    selected: _selectedIndex == 0,
                    onTap: () {
                      _onItemTapped(0);
                      Navigator.pop(context);
                    },
                  ),
                  ListTile(
                    title: _selectedIndex == 1
                        ? Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(4),
                              color: Color.fromRGBO(15, 133, 219, 1),
                            ),
                            padding:
                                EdgeInsets.only(left: 14, top: 12, bottom: 12),
                            child: Row(
                              children: [
                                SvgPicture.asset('assets/scan.svg'),
                                const SizedBox(
                                  width: 14,
                                ),
                                Text('Scanned Files',
                                    style: Theme.of(context)
                                        .textTheme
                                        .titleSmall
                                        ?.apply(color: Colors.white)),
                              ],
                            ),
                          )
                        : Row(
                            children: [
                              SvgPicture.asset(
                                'assets/scan.svg',
                                color: Colors.black,
                              ),
                              const SizedBox(
                                width: 14,
                              ),
                              Text(
                                'Scanned Files',
                                style: Theme.of(context).textTheme.titleSmall,
                              ),
                            ],
                          ),
                    selected: _selectedIndex == 1,
                    onTap: () {
                      _onItemTapped(1);
                      Navigator.pop(context);
                    },
                  ),
                  ListTile(
                    title: _selectedIndex == 2
                        ? Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(4),
                              color: Color.fromRGBO(15, 133, 219, 1),
                            ),
                            padding:
                                EdgeInsets.only(left: 14, top: 12, bottom: 12),
                            child: Row(
                              children: [
                                SvgPicture.asset(
                                  'assets/settings.svg',
                                  color: Colors.white,
                                ),
                                const SizedBox(
                                  width: 14,
                                ),
                                Text('Settings',
                                    style: Theme.of(context)
                                        .textTheme
                                        .titleSmall
                                        ?.apply(color: Colors.white)),
                              ],
                            ),
                          )
                        : Row(
                            children: [
                              SvgPicture.asset(
                                'assets/settings.svg',
                              ),
                              const SizedBox(
                                width: 14,
                              ),
                              Text(
                                'Settings',
                                style: Theme.of(context).textTheme.titleSmall,
                              ),
                            ],
                          ),
                    selected: _selectedIndex == 2,
                    onTap: () {
                      // Update the state of the app
                      _onItemTapped(2);
                      // Then close the drawer
                      Navigator.pop(context);
                    },
                  ),
                  const SizedBox(
                    height: 320,
                  ),
                  Container(
                    height: 1,
                    color: Color.fromRGBO(217, 217, 217, 1),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 32, top: 22),
                    child: Row(
                      children: [
                        Icon(Icons.logout_outlined),
                        const SizedBox(
                          width: 12,
                        ),
                        InkWell(
                            onTap: () async{
                              print(widget.userType);
                              final SharedPreferences prefs =await SharedPreferences.getInstance();

                                prefs.remove("phno");
                                prefs.remove("email");
                                context.read<GetemployeeCubit>().reset();
                                Navigator.of(context).pushAndRemoveUntil(
                                    MaterialPageRoute(
                                        builder: (context) => Commonlogin()),
                                    (Route<dynamic> route) => false);

                            },
                            child: Text(
                              'Logout',
                              style: Theme.of(context)
                                  .textTheme
                                  .bodySmall
                                  ?.apply(fontSizeDelta: 2),
                            )),
                      ],
                    ),
                  ),
                ],
              ),
            ),

      body: Center(
        child: (widget.userType == "admin")
            ? _adminwidgetOptions[_selectedIndex]
            : _EMPwidgetOptions[_selectedIndex],
      ),
      // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}
