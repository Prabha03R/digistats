// import 'package:email_otp/email_otp.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:otp_text_field/otp_field.dart';
// import 'package:otp_text_field/otp_field_style.dart';
// import 'package:otp_text_field/style.dart';
//
// import 'create_password.dart';
//
//
// class Otpverification extends StatefulWidget {
//
//   const Otpverification({super.key});
//
//   @override
//   State<Otpverification> createState() => _OtpverificationState();
// }
// class _OtpverificationState extends State<Otpverification> {
//   bool color=false;
//   final _formKey = GlobalKey<FormState>();
//   OtpFieldController otps=new OtpFieldController();
//  //TextEditingController otp = TextEditingController();
//   EmailOTP myauth = EmailOTP();
//
//   @override
//   Widget build(BuildContext context) {
//
//     return  Scaffold(
//       body: Container(
//         margin: EdgeInsets.only(left: 20),
//         child: SingleChildScrollView(
//           child: Form(
//             key: _formKey,
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//
//                 const SizedBox(height: 50,),
//                 InkWell(
//                   onTap: (){
//                     Navigator.pop(context);
//                   },
//                   child: Container(
//                       height: 26
//                       ,width: 26,
//                       decoration: BoxDecoration(
//                           borderRadius: BorderRadius.circular(4),
//                           color:Color.fromRGBO(246, 246, 246, 1)
//                       ),
//                       child: Icon(Icons.arrow_back,size: 18,color:Color.fromRGBO(0, 8, 66, 1))),
//                 ),
//                 const SizedBox(height: 22,),
//                 Text('You\'ve got mail',style: Theme.of(context).textTheme.bodyLarge?.apply(
//                     color:Color.fromRGBO(49, 49, 49, 1)
//                 )),
//                 const SizedBox(height: 20,),
//                 Text('We have send the OTP verification code to your email address.Check your email and enter the code below.',style: Theme.of(context).textTheme.bodySmall
//                     ?.apply(fontSizeDelta: 2,color:Color.fromRGBO(37, 37, 37, 1)),),
//                 const SizedBox(height: 34,),
//                 OTPTextField(
//                   otpFieldStyle: OtpFieldStyle(
//
//
//                       enabledBorderColor:Color.fromRGBO(244, 244, 244, 1) ,
//                       focusBorderColor: Color.fromRGBO(176, 185, 243, 1),
//
//                       backgroundColor: color?Color.fromRGBO(244, 244, 244, 1):Color.fromRGBO(176, 185, 243, 1)//(here)
//                   ),
//                   controller:otps,
//                   length: 4,
//                   width: MediaQuery.of(context).size.width,
//                   fieldWidth: 68,
//                   outlineBorderRadius: 12,
//                   style: TextStyle(
//                       fontSize: 17
//                   ),
//                   textFieldAlignment: MainAxisAlignment.spaceEvenly,
//                   fieldStyle: FieldStyle.box,
//                   onChanged: (pin) {
//                     setState(() {
//                       color=true ;
//                     });
//                     print(color);
//                   },
//                 ),
//                 // Row(
//                 //   // mainAxisAlignment: MainAxisAlignment.center,
//                 //
//                 //   children: [
//                 //     Container(
//                 //       padding: EdgeInsets.only(right: 12,left: 12),
//                 //       height: 70,width: 68,
//                 //       decoration: BoxDecoration(
//                 //           borderRadius: BorderRadius.circular(12),color: Color.fromRGBO(244, 244, 244, 1)
//                 //
//                 //       ),
//                 //       child: TextFormField(
//                 //         controller: otp,
//                 //         textAlign: TextAlign.center,
//                 //         cursorColor:Color.fromRGBO(153, 153, 153, 1) ,
//                 //        // maxLength: 1,
//                 //
//                 //
//                 //         decoration: InputDecoration(
//                 //           //counter: Offstage(),
//                 //           enabledBorder: UnderlineInputBorder(
//                 //             borderSide: BorderSide(color: Colors.black),
//                 //           ),
//                 //           focusedBorder: UnderlineInputBorder(
//                 //             borderSide: BorderSide(color: Colors.black),
//                 //           ),
//                 //         ),
//                 //
//                 //       ),
//                 //     ),
//                 //     const SizedBox(width: 14,),
//                 //     Container(
//                 //       padding: EdgeInsets.only(right: 12,left: 12),
//                 //       height: 70,width: 68,
//                 //       decoration: BoxDecoration(
//                 //           borderRadius: BorderRadius.circular(12),color: Color.fromRGBO(244, 244, 244, 1)
//                 //
//                 //       ),
//                 //       child: TextField( textAlign: TextAlign.center,
//                 //         cursorColor:Color.fromRGBO(153, 153, 153, 1) ,
//                 //         maxLength: 1,
//                 //
//                 //
//                 //         decoration: InputDecoration(
//                 //           counter: Offstage(),
//                 //           enabledBorder: UnderlineInputBorder(
//                 //             borderSide: BorderSide(color: Colors.black),
//                 //           ),
//                 //           focusedBorder: UnderlineInputBorder(
//                 //             borderSide: BorderSide(color: Colors.black),
//                 //           ),
//                 //         ),
//                 //
//                 //       ),
//                 //     ),
//                 //     const SizedBox(width: 14,),
//                 //     Container(
//                 //       padding: EdgeInsets.only(right: 12,left: 12),
//                 //       height: 70,width: 68,
//                 //       decoration: BoxDecoration(
//                 //           borderRadius: BorderRadius.circular(12),color: Color.fromRGBO(176, 185, 243, 1)
//                 //
//                 //       ),
//                 //       child: TextField( textAlign: TextAlign.center,
//                 //         cursorColor:Color.fromRGBO(153, 153, 153, 1) ,
//                 //         maxLength: 1,
//                 //
//                 //
//                 //         decoration: InputDecoration(
//                 //           counter: Offstage(),
//                 //           enabledBorder: UnderlineInputBorder(
//                 //             borderSide: BorderSide(color: Colors.black),
//                 //           ),
//                 //           focusedBorder: UnderlineInputBorder(
//                 //             borderSide: BorderSide(color: Colors.black),
//                 //           ),
//                 //         ),
//                 //
//                 //       ),
//                 //     ),
//                 //     const SizedBox(width: 14,),
//                 //     Container(
//                 //       padding: EdgeInsets.only(right: 12,left: 12),
//                 //       height: 70,width: 68,
//                 //       decoration: BoxDecoration(
//                 //           borderRadius: BorderRadius.circular(12),color: Color.fromRGBO(244, 244, 244, 1)
//                 //
//                 //       ),
//                 //       child: TextField( textAlign: TextAlign.center,
//                 //         cursorColor:Color.fromRGBO(153, 153, 153, 1) ,
//                 //         maxLength: 1,
//                 //
//                 //
//                 //         decoration: InputDecoration(
//                 //           counter: Offstage(),
//                 //           enabledBorder: UnderlineInputBorder(
//                 //             borderSide: BorderSide(color: Colors.black),
//                 //           ),
//                 //           focusedBorder: UnderlineInputBorder(
//                 //             borderSide: BorderSide(color: Colors.black),
//                 //             // borderSide: BorderSide(color: Color.fromRGBO(153, 153, 153, 1)),
//                 //           ),
//                 //         ),
//                 //
//                 //       ),
//                 //     )
//                 //
//                 //   ],
//                 // ),
//                 const SizedBox(height: 36,),
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//
//                     Text('Didn\'t receive email?',style: Theme.of(context).textTheme.bodySmall?.apply(
//                         fontSizeDelta: 3
//                     ),),
//
//                   ],
//                 ),
//                 const SizedBox(height: 14,),
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//
//                     Text('You can resend code in 55 s',style: Theme.of(context).textTheme.bodySmall?.apply(
//                         fontSizeDelta: 3)
//                     ),
//
//                   ],
//                 ),
//                 const SizedBox(height: 263,),
//                 InkWell(
//                   onTap:() async{
//                     if (await myauth.verifyOTP(otp: otps) == true) {
//
//                     ScaffoldMessenger.of(context)
//                         .showSnackBar(const SnackBar(
//                     content: Text("OTP is verified"),
//                     ));
//                     Navigator.push(
//                       context,
//                       MaterialPageRoute(builder: (context) => Cretepassword()),
//                     );
//                     } else {
//                       print(otps);
//                     ScaffoldMessenger.of(context)
//                         .showSnackBar(const SnackBar(
//                     content: Text("Invalid OTP"),
//                     ));
//                       Navigator.push(
//                         context,
//                         MaterialPageRoute(builder: (context) => Cretepassword()),
//                       );
//                     }
//
//
//                   },
//                   child: Container(
//                     height: 44,
//                     decoration: BoxDecoration(
//                         borderRadius: BorderRadius.circular(12),
//                         color: Color.fromRGBO(15, 133, 219, 1)
//
//
//                     ),
//                     margin: EdgeInsets.only(right: 20,left: 20),
//
//
//                     child: Row(
//                       mainAxisAlignment: MainAxisAlignment.center,
//                       children: [
//                         Text('Continue',style: Theme.of(context).textTheme.headlineSmall?.apply(
//                             color:Color.fromRGBO(255, 255, 255, 1)
//                         ),),
//                       ],
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//
//       ),
//     );
//   }
// }
