// part of 'empdocs_cubit.dart';
//
// @immutable
// abstract class EmpdocsState extends Equatable {
//   const EmpdocsState();
// }
//
// class EmpdocsInitial extends EmpdocsState {
//   @override
//   List<Object> get props => [];
// }
// class Empdocsloading extends EmpdocsState {
//   @override
//   List<Object> get props => [];
// }
// class Empdocsloaded extends EmpdocsState {
//  // Employeedataloaded({required this.employeedetails});
//  // final   List<Employeedetails> employeedetails;
//   @override
//   List<Object> get props => [];
// }
// class Empdocserror extends EmpdocsState {
//   @override
//   List<Object> get props => [];
// }
