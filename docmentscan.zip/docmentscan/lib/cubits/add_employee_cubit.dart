import 'package:bloc/bloc.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:meta/meta.dart';

part 'add_employee_state.dart';

class AddEmployeeCubit extends Cubit<AddEmployeeState> {
  AddEmployeeCubit() : super(AddEmployeeInitial());

  Future<void> Addemployee(
      {String firstname = '',
      String lastname = '',
      String gender = '',
      String dob = '',
      String phno = '',
      String address = '',
      String email = '',

      required String image}) async {
    try {
      final fcmToken = await FirebaseMessaging.instance.getToken();
      emit(AddEmployeeloading());

      var id=FirebaseFirestore.instance.collection('employee').doc();
      id.set({
        "firstname": firstname,
        "lastname": lastname,
        "gender": gender,
        "dob": dob,
        "phno": phno,
        "address": address,
        "image": image,
        "id": id.id,
        "documents":[]
      });
      print("---$phno");
      emit(AddEmployeeloaded());
      Fluttertoast.showToast(msg: "Employee added Successfully");
    } on FirebaseAuthException catch (e) {
      emit(AddEmployeeerror());
      Fluttertoast.showToast(msg: "Employee added Failed");
    }
  }

  void reset() {
    emit(AddEmployeeInitial());
  }
}
