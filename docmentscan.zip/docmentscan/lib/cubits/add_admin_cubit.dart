import 'package:bloc/bloc.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:meta/meta.dart';

part 'add_admin_state.dart';

class AddAdminCubit extends Cubit<AddAdminState> {
  AddAdminCubit() : super(AddAdminInitial());

  Future<void> Addadmin(
      {String firstname = '',
      String lastname = '',
      String gender = '',
      String dob = '',
      String email = '',
      String password = '',
      String address = '',

      required String image}) async {
    try {


      emit(AddAdminloading());
      FirebaseAuth.instance
          .createUserWithEmailAndPassword(email: email, password: password)
          .then((value) async {
        await FirebaseFirestore.instance
            .collection('users')
            .doc(value.user?.uid)
            .set({
              "firstname": firstname,
              "lastname": lastname,
              "gender": gender,
              "dob": dob,
              "email": email,
              "password": password,
              "address": address,
              "image": image,
              "id": value.user?.uid

            })
            .then((value) {})
            .onError((error, stackTrace) {
            });
        User? user = value.user;
        if (user != null) {
          // Set the profile image URL in the user's profile
          // var profileUpdate = UserProfileChangeRequest()
          //   ..photoURL = image;

          // await user.updatePhotoURL(image);
          // String? name='';
          await user.updateProfile(
              photoURL: image, displayName: '${firstname}' '${lastname}');
          await user.reload();
          // The user's profile image URL is now set in FirebaseAuth.
          // Optionally, you can also update the user's profile in Firestore or Realtime Database with the download URL.
        }
        emit(AddAdminloaded());
        Fluttertoast.showToast(msg: "Admin added Successfully");
      }).onError((error, stackTrace) {
        Fluttertoast.showToast(msg: "Error : $error");
        emit(AddAdminerror());
      });
    } on FirebaseAuthException catch (e) {
      emit(AddAdminerror());
      Fluttertoast.showToast(msg: "Admin added Failed");
    }
  }

  void reset() {
    emit(AddAdminInitial());
  }
}
