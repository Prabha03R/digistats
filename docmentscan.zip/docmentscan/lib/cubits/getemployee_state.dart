part of 'getemployee_cubit.dart';

@immutable

abstract class GetemployeeState extends Equatable {
  const GetemployeeState();
}

class GetemployeeInitial extends GetemployeeState {
  @override
  List<Object> get props => [];
}
class Getemployeeloading extends GetemployeeState {
  @override
  List<Object> get props => [];
}
class Getemployeeloaded extends GetemployeeState {
  Getemployeeloaded({required this.employeedetails, required this.phno});
  final   List<Employeedetails> employeedetails;
  final String phno;
  @override
  List<Object> get props => [employeedetails,phno];
}
class Getemployeeerror extends GetemployeeState {
  @override
  List<Object> get props => [];
}
