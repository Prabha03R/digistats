// import 'package:bloc/bloc.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:equatable/equatable.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:firebase_messaging/firebase_messaging.dart';
// import 'package:fluttertoast/fluttertoast.dart';
// import 'package:meta/meta.dart';
//
// part 'empdocs_state.dart';
//
// class EmpdocsCubit extends Cubit<EmpdocsState> {
//   EmpdocsCubit() : super(EmpdocsInitial());
//   Future<void> Empdoc(
//       {required String doc}) async {
//     try {
//       final fcmToken = await FirebaseMessaging.instance.getToken();
//
//       emit(Empdocsloading());
//       FirebaseAuth.instance
//           .update
//
//           .then((value) async {
//         await FirebaseFirestore.instance
//             .collection('employee')
//             .doc(value.user?.uid)
//             .set({
//           "image": doc
//         })
//             .then((value) {})
//
//             .onError((error, stackTrace) {
//
//         });
//
//         emit(Empdocsloaded());
//         Fluttertoast.showToast(msg: "Admin added Successfully");
//       }).onError((error, stackTrace) {
//         Fluttertoast.showToast(msg: "Error : $error");
//         emit(Empdocserror());
//       });
//     } on FirebaseAuthException catch (e) {
//       emit(Empdocserror());
//       Fluttertoast.showToast(msg: "Admin added Failed");
//     }
//   }
//
//   void reset() {
//     emit(EmpdocsInitial());
//   }
// }
//
//
