part of 'employeedata_cubit.dart';

@immutable

abstract class EmployeedataState extends Equatable {
  const EmployeedataState();
}

class EmployeedataInitial extends EmployeedataState {
  @override
  List<Object> get props => [];
}
class Employeedataloading extends EmployeedataState {
  @override
  List<Object> get props => [];
}
class Employeedataloaded extends EmployeedataState {
  Employeedataloaded({required this.employeedetails});
  final   List<Employeedetails> employeedetails;
  @override
  List<Object> get props => [employeedetails];
}
class Employeedataerror extends EmployeedataState {
  @override
  List<Object> get props => [];
}
