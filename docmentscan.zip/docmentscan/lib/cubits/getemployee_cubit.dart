import 'package:bloc/bloc.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:equatable/equatable.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:meta/meta.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/getemployee.dart';

part 'getemployee_state.dart';

class GetemployeeCubit extends Cubit<GetemployeeState> {
  GetemployeeCubit() : super(GetemployeeInitial());

  Future<void> getUseData({String phno = ''}) async {
   try {
      emit(Getemployeeloading());
      List<Employeedetails> employeedetails = [];
      List<Employeedetails> testlist = [];

      await FirebaseFirestore.instance
          .collection('employee')
          .get()
          .then((value) async {
        value.docs.forEach((element) {
          Employeedetails getdata = Employeedetails.fromJson(element.data());
          employeedetails.add(getdata);

        });
        employeedetails.forEach((element) {
          if (element.phno == phno) {
            testlist.add(element);
          }
        });
        if (testlist.isEmpty) {
          emit(Getemployeeerror());
          Fluttertoast.showToast(msg: "Invalid Credentials");
        } else {
           final SharedPreferences prefs =await SharedPreferences.getInstance();
           print(testlist.first.phno!);
           prefs.setString('phno', testlist.first.phno.toString());
          emit(Getemployeeloaded(employeedetails: testlist,phno:testlist.first.phno.toString()));
        }
      });
    }
    on FirebaseFirestore catch (e) {
      emit(Getemployeeerror());
      Fluttertoast.showToast(
          msg: "Something went wrong please try again later!!");
    }
  }

  void reset() {
    emit(GetemployeeInitial());
  }
}
