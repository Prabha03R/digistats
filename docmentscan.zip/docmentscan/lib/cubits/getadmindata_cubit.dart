import 'package:bloc/bloc.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:equatable/equatable.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:meta/meta.dart';
import '../models/admindata.dart';

part 'getadmindata_state.dart';

class GetadmindataCubit extends Cubit<GetadmindataState> {
  GetadmindataCubit() : super(GetadmindataInitial());

  Future<void> getadminData() async {
    try {
      emit(Getadmindataloading());

      await FirebaseFirestore.instance
          .collection('users')
          .snapshots()
          .listen((event) {
        List<Admindata> admindata = [];
        event.docs.forEach((element) {
          Admindata getdata = Admindata.fromJson(element.data());
          admindata.add(getdata);
        });
        emit(Getadmindataloaded(admindata: admindata));
      });
    } on FirebaseFirestore catch (e) {
      emit(Getadmindataerror());
      Fluttertoast.showToast(msg: "Cannot Get Users data!!");
    }
  }
  Future<void> getadminDatasilent() async {
    try {
     // emit(Getadmindataloading());

      await FirebaseFirestore.instance
          .collection('users')
          .snapshots()
          .listen((event) {
        List<Admindata> admindata = [];
        event.docs.forEach((element) {
          Admindata getdata = Admindata.fromJson(element.data());
          admindata.add(getdata);
        });
        emit(Getadmindataloaded(admindata: admindata));
      });
    } on FirebaseFirestore catch (e) {
      emit(Getadmindataerror());
      Fluttertoast.showToast(msg: "Cannot Get Users data!!");
    }
  }
}
