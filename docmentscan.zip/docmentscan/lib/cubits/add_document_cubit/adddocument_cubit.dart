import 'package:bloc/bloc.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:equatable/equatable.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';
import '../../models/admindata.dart';
import '../../models/getemployee.dart';
import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;
import 'dart:io' ;

part 'adddocument_state.dart';

class AdddocumentCubit extends Cubit<AdddocumentState> {
  AdddocumentCubit() : super(AdddocumentInitial());

  Future<void> addDocument({File? scannedDocumentFile, List<Employeedetails>? empdetails, String? userType, Admindata? curadmin})async{
    emit(AdddocumentLoading());
    String? downloadURL = await uploadDocumentToFirebase(scannedDocumentFile!);
   if(userType =="emp"){


     if (downloadURL != null) {

       final SharedPreferences prefs =await SharedPreferences.getInstance();
       String? phno= prefs.getString('phno');
       Employeedetails curEmp= empdetails!.firstWhere((element) => element.phno==phno);
       var li=curEmp.docs??[];
       li.add(downloadURL);
       FirebaseFirestore.instance.collection('employee').doc(curEmp.id).set(
           {
             "documents":curEmp.docs,
             "senderName":'${curEmp.lastname} ${curEmp.firstname}',
             "date": "${DateFormat('dd-MM-yyyy').format(DateTime.now())}"
           },
           SetOptions(merge: true)
       ).then((value) {
         emit(AdddocumentAdded(userType:userType??'',phonNo:phno??""));
         Fluttertoast.showToast(msg: "Pdf saved successfully",backgroundColor: Colors.green);
       });
       // Handle the downloadURL as needed
     } else {
       // Handle the case when uploading to Firebase failed or no scanned document is available
       print('Uploading document to Firebase failed or no scanned document available.');
     }
   }else{
     if (downloadURL != null) {
       emit(AdddocumentLoading());
       final userdata = FirebaseAuth.instance.currentUser;
       FirebaseFirestore.instance.collection('users').doc(curadmin!.id).set({
         "sendDocuments":FieldValue.arrayUnion([{
           "pdfDocument": downloadURL,
           "senderName":userdata?.displayName ,
           "date": "${DateFormat('dd-MM-yyyy').format(DateTime.now())}"
         }])
       },
           SetOptions(merge : true)

       ).then((value) {
         // context.read<GetadmindataCubit>().getadminDatasilent();
         emit(AdddocumentAdded(userType:userType??'', phonNo: ''));
         Fluttertoast.showToast(msg: "Pdf saved successfully",backgroundColor: Colors.green);

       });

     }else{

     }
   }

  }
  Future<String?> uploadDocumentToFirebase(File _scannedDocument) async {
    try {
      final String fileName = DateTime.now().millisecondsSinceEpoch.toString();
      final firebase_storage.Reference storageReference =
      firebase_storage.FirebaseStorage.instance.ref().child('employeedocs/$fileName');

      final firebase_storage.UploadTask uploadTask = storageReference.putFile(_scannedDocument);
      final firebase_storage.TaskSnapshot storageSnapshot = await uploadTask;
      final String downloadURL = await storageSnapshot.ref.getDownloadURL();

      return downloadURL;
    } catch (e) {
      print('Error uploading document to Firebase: $e');
      return null;
    }
  }





  void resetCubit(){
    emit(AdddocumentInitial());  }
}
