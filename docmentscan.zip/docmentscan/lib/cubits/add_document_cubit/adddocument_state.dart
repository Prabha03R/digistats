part of 'adddocument_cubit.dart';

abstract class AdddocumentState extends Equatable {
  const AdddocumentState();
}

class AdddocumentInitial extends AdddocumentState {
  @override
  List<Object> get props => [];
}
class AdddocumentLoading extends AdddocumentState {
  @override
  List<Object> get props => [];
}
class AdddocumentAdded extends AdddocumentState {
  const AdddocumentAdded({required this.userType, required this. phonNo});
  final  String userType;
  final  String phonNo;
  @override
  List<Object> get props => [userType];
}
class AdddocumentFailed extends AdddocumentState {
  @override
  List<Object> get props => [];
}
