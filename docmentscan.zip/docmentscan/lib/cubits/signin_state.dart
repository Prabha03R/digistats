part of 'signin_cubit.dart';

@immutable

abstract class SigninState extends Equatable {
  const SigninState();
}

class SigninInitial extends SigninState {
  @override
  List<Object> get props => [];
}
class Signinloading extends SigninState {
  @override
  List<Object> get props => [];
}
class Signedin extends SigninState {

  @override
  List<Object> get props => [];
}
class Signinerror extends SigninState {
  @override
  List<Object> get props => [];
}
