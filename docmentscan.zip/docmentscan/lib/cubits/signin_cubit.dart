import 'package:bloc/bloc.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:equatable/equatable.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:meta/meta.dart';
import 'package:shared_preferences/shared_preferences.dart';

part 'signin_state.dart';

class SigninCubit extends Cubit<SigninState> {
  SigninCubit() : super(SigninInitial());

  Future SignIn({String email = '', String password = ''}) async {
    try {
      final fcmToken = await FirebaseMessaging.instance.getToken();
      final SharedPreferences prefs =await SharedPreferences.getInstance();
      await FirebaseAuth.instance
          .signInWithEmailAndPassword(email: email, password: password)
          .then((value) => {
                FirebaseFirestore.instance
                    .collection('users')
                    .doc(value.user?.uid)
                    .update(
                  {
                    "fcmtoken": "$fcmToken",
                  },
                ),
      prefs.setString('email', value.user?.email??"")
              });
      emit(Signedin());
      Fluttertoast.showToast(msg: "Login successfully",backgroundColor: Colors.green);
    } catch (e) {
      emit(Signinerror());
      Fluttertoast.showToast(msg: "Error :$e");
    }
  }

  void reset() {
    emit(SigninInitial());
  }
}
