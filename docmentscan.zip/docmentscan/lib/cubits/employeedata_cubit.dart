import 'package:bloc/bloc.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:equatable/equatable.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:meta/meta.dart';

import '../models/getemployee.dart';

part 'employeedata_state.dart';

class EmployeedataCubit extends Cubit<EmployeedataState> {
  EmployeedataCubit() : super(EmployeedataInitial());

  Future<void> getemployeeData() async {
    try {
      emit(Employeedataloading());

      await FirebaseFirestore.instance
          .collection('employee')
          .snapshots()

          .listen((event) {
        List<Employeedetails> employeedetails = [];
        event.docs.forEach((element){
          Employeedetails getdata = Employeedetails.fromJson(element.data());
          employeedetails.add(getdata);
        });
        emit(Employeedataloaded(employeedetails: employeedetails));
      });
    } on FirebaseFirestore catch (e) {
      emit(Employeedataerror());
      Fluttertoast.showToast(msg: "Cannot Get Users data!!");
    }
  }
}
