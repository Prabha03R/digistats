part of 'add_employee_cubit.dart';

@immutable
abstract class AddEmployeeState {}

class AddEmployeeInitial extends AddEmployeeState {}
class AddEmployeeloading extends AddEmployeeState {}
class AddEmployeeloaded extends AddEmployeeState {}
class AddEmployeeerror extends AddEmployeeState {}
