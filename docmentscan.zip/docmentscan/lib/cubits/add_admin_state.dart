part of 'add_admin_cubit.dart';

@immutable
abstract class AddAdminState {}

class AddAdminInitial extends AddAdminState {}
class AddAdminloading extends AddAdminState {}
class AddAdminloaded extends AddAdminState {}
class AddAdminerror extends AddAdminState {}

