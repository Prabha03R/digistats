part of 'getadmindata_cubit.dart';

@immutable

abstract class GetadmindataState extends Equatable {
  const GetadmindataState();
}

class GetadmindataInitial extends GetadmindataState {
  @override
  List<Object> get props => [];
}
class Getadmindataloading extends GetadmindataState {
  @override
  List<Object> get props => [];
}
class Getadmindataloaded extends GetadmindataState {
  Getadmindataloaded({required this.admindata});
  final List<Admindata> admindata;
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
          other is Getadmindataloaded &&
              runtimeType == other.runtimeType &&
              admindata == other.admindata;

  @override
  int get hashCode => admindata.hashCode;
  @override
  List<Object> get props => [admindata];
}


class Getadmindataerror extends GetadmindataState {
  @override
  List<Object> get props => [];
}

