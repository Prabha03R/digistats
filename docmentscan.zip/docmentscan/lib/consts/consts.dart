export './app_assets.dart';
export './app_colors.dart';
export './app_consts.dart';
export './app_sizes.dart';
export './app_styles.dart';

import 'package:get/get.dart';
import '/controllers/setting_controller.dart';

SettingController settingController = Get.find();
