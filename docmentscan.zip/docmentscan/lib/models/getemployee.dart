class Employeedetails {
  String? firstname;
  String? lastname;
  String? gender;
  String? dob;
  String? phno;
  String? password;
  String? address;
  String? image;
  String? id;
  String? senderName;
  String? date;
  List? docs;

  Employeedetails(
      {this.firstname, this.lastname, this.gender, this.dob, this.phno,this.password,this.address,this.image,this.id,this.docs,this.senderName,this.date});

  Employeedetails.fromJson(Map<String, dynamic> json) {
    firstname = json['firstname'];
    lastname = json['lastname'];
    gender = json['gender'];
    dob = json['dob'];
    phno = json['phno'];
    password = json['password'];
    address = json['address'];
    image = json['image'];
    id = json['id'];
    date = json['date'];
    senderName = json['senderName'];
    docs=json['documents']??[];
  }


}
