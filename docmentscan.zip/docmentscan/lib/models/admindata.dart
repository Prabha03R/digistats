class Admindata {
  String? firstname;
  String? lastname;
  String? gender;
  String? dob;
  String? email;
  String? password;
  String? address;
  String? image;
  String? id;
  List? docs;
  List<SendDocuments>? sendDocuments;
  Admindata(
      {this.firstname, this.lastname, this.gender, this.dob, this.email,this.password,this.address,this.image,this.id,this.sendDocuments,this.docs});

  Admindata.fromJson(Map<String, dynamic> json) {
    firstname = json['firstname'];
    lastname = json['lastname'];
    gender = json['gender'];
    dob = json['dob'];
    email = json['email'];
    password = json['password'];
    address = json['address'];
    image = json['image'];
    id = json['id'];
    docs=json['documents']??[];
    if (json['sendDocuments'] != null) {
      sendDocuments = <SendDocuments>[];
      json['sendDocuments'].forEach((v) {
        sendDocuments!.add( SendDocuments.fromJson(v));
      });
    }

  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['firstname'] = this.firstname;
    data['lastname'] = this.lastname;
    data['gender'] = this.gender;
    data['dob'] = this.dob;
    data['email'] = this.email;
    data['password'] = this.password;
    data['address'] = this.address;
    data['image'] = this.image;
    data['id']= this.id;
    if (this.sendDocuments != null) {
      data['sendDocuments'] =
          this.sendDocuments!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class SendDocuments {
  String? pdfDocument;
  String? senderName;
  String? date;

  SendDocuments({this.pdfDocument, this.senderName, this.date});

  SendDocuments.fromJson(Map<String, dynamic> json) {
    pdfDocument = json['pdfDocument'];
    senderName = json['senderName'];
    date = json['date'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['pdfDocument'] = this.pdfDocument;
    data['senderName'] = this.senderName;
    data['date'] = this.date;
    return data;
  }
}
