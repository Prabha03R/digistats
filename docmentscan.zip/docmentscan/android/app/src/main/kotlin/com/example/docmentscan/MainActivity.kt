package com.example.docmentscan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
